"""Blast Radius selector, team 2696.

For each patch: work out which tests could notice the change, using a map built
offline from sqlglot at the pinned commit (tools/build_map), then pack those tests
onto the cheapest number of workers.

The rule everywhere: when unsure, select more. A missed failing test costs 300 s,
far more than any test we might run needlessly.

How a changed file is handled:
  - Python, only comments/formatting changed (same syntax tree): no tests.
  - Python, a statement inside a function or method changed: the tests that ran
    that statement. If the statement also ran while modules were importing, every test.
  - Python, a class-level statement (class attributes, dict tables): the tests that
    used that class or a subclass; if no test did, the tests that use the names it defines.
  - Python, module-level constant: the tests that depend on the names it defines.
  - Python that no longer parses, or import-time changes we can't place: every test.
  - Fixtures and other data files: the tests that opened the file (or listed its dir).
  - Anything we can't parse or locate: every test.
"""

from __future__ import annotations

import ast
import builtins
import gc
import json
import marshal
import os
import re
import sys
import time
import types
import unicodedata
import zlib
from pathlib import Path

DATA = Path(os.environ.get("BR_DATA", "/data"))
APP = Path(__file__).resolve().parent
MAP_PATH = Path(os.environ.get("BR_MAP", APP / "maps" / "map.json.gz"))
SRC = Path(os.environ.get("BR_SRC", APP / "src"))

TWINS_PATH = Path(os.environ.get("BR_TWINS", APP / "maps" / "twins.json.gz"))
EQUIV = os.environ.get("BR_EQUIV", "1") == "1"  # twin-comparison infection map (equiv.py)
LAMBDA_PATH = Path(os.environ.get("BR_LAMBDA_MAP", APP / "maps" / "lambdas.json.gz"))
LAMBDA = os.environ.get("BR_LAMBDA", "1") == "1"  # lambda-call map (equiv.py)
REQUIRED_PATH = Path(os.environ.get("BR_REQUIRED_MAP", APP / "maps" / "required.json.gz"))
S7 = os.environ.get("BR_S7", "1") == "1"  # arg_types flag flips: required-key map (equiv.py)
LOAD_GUARD = os.environ.get("BR_LOADGUARD", "1") == "1"  # names read at load, users near all: all
# The default Dialect's parser_class (dialects/dialect.py): generators/duckdb.py's import-time
# parse runs it, though only 771 tests use it (work/sets/bpset b005 failed 1020 at collection).
# Func too: that parse builds functions through Func.from_arg_list, which reads is_var_len_args and
# var_len_arg_key (work/sets/clset c000, c001 failed 1020 at collection, Func has 998 users).
LOAD_PARSE_CLASSES = {"sqlglot.parsers.base.BaseParser", "sqlglot.expressions.core.Func"}
# What the import-time parse reads on the classes it validates (tools/build_map/load_validated.py:
# arg_types along each MRO and the literals and module dicts it spreads, Min's and List's
# is_var_len_args): a hunk changing it other than by flag flips S7 vouches for or new optional keys
# selects all (work/sets/mcset: 23 QUERY_MODIFIERS flips failed 1020 tests at collection).
LOADVAL_PATH = Path(os.environ.get("BR_LOADVAL_MAP", APP / "maps" / "loadval.json"))
LOADVAL = os.environ.get("BR_LOADVAL", "1") == "1"
MAX_WORKERS = 8
WORKER_COST_MS = 2000
ALL = None  # sentinel: select every test
# The scorer stops a run at 4.5 minutes and then has no answers at all. Past this many
# seconds every remaining commit gets every test, unanalysed (a normal run takes ~2 s).
RUN_BUDGET_S = float(os.environ.get("BR_RUN_BUDGET_S", "150"))
STARTED = time.monotonic()

# Config files that can change how pytest itself runs (pytest reads its settings from
# pyproject.toml / setup.cfg / tox.ini / pytest.ini, before any test can record a read).
PYTEST_CONFIG = {"pytest.ini", "tox.ini", "conftest.py", "tests/conftest.py", "pyproject.toml", "setup.cfg"}

# Class attributes that register a class under a name other classes are looked up by
# (an expression's key, a function's SQL names): an edit can break *other* classes' tests.
REGISTRY_ATTRS = {"key", "_sql_names", "sql_names"}

# Class attribute readers (tools/build_map/attr_index.py): narrows a change to a plain
# class attribute's value to the tests that ran code naming it (Selector.attr_narrow).
ATTRS_PATH = Path(os.environ.get("BR_ATTRS", APP / "maps" / "attrs.json.gz"))
ATTR_NARROW = os.environ.get("BR_ATTR_NARROW", "1") == "1"
S5C = os.environ.get("BR_S5C", "1") == "1"  # attr_narrow: per-owner import reads (attrs "import_owner")
# S6, dict entry readers (tools/build_map/entries.py): narrows a change to the values of
# entries of a dict literal in a class body to the tests that read those entries
# (Selector.entry_narrow).
ENTRIES_PATH = Path(os.environ.get("BR_ENTRIES", APP / "maps" / "entries.json.gz"))
ENTRY_NARROW = os.environ.get("BR_S6", "1") == "1"
# H1: a def header change that only changes default values selects the tests that ran the
# def's lines, like an edit of its body (Selector.defaults_only).
DEFAULTS_NARROW = os.environ.get("BR_H1", "1") == "1"
# H0: a def header change of a function whose body ran while modules
# load selects all, like a body statement that runs at import (the header can make the
# import-time call raise, and then whole test files fail at collection).
DEFHEAD_IMPORT = os.environ.get("BR_H0", "1") == "1"
# A module constant read by a function body that runs while modules load selects all: what
# the call builds from it is read by tests that never name it (dialect.py's _Dialect.__new__
# builds every dialect's INVERSE_TIME_MAPPING from STRICT_TIME_FORMATS), as does a new value
# that may raise while loading. Narrowing stays for the rest (Selector.modconst_unsafe).
MODCONST_GUARD = os.environ.get("BR_MODCONST", "1") == "1"
# A1: an attribute that the patched module's load-time code newly reads and that nothing
# defines (exp.ArraySortt in a TRANSFORMS key) is an AttributeError while it loads.
LOADATTR = os.environ.get("BR_LOADATTR", "1") == "1"
# C1: a call that the patched module's load-time code newly makes, to a plain def of a sqlglot
# module, with arguments that the def's signature rejects (TypeError while the module loads).
LOADCALL = os.environ.get("BR_LOADCALL", "1") == "1"
# Off: class-level changes in a parser/generator/tokenizer class could also select the users
# of the dialects that own it (attrs "owners"), since code reads those attributes through
# the dialect. Measured +11.5 s on the sample, +24.7 s on m21, with no labeled miss to fix
# (findings/class-users-gap.md). S5 always adds them, restricted to the readers.
OWNER_USERS = os.environ.get("BR_OWNER_USERS", "0") == "1"
# A sqlglot module that no test imports, runs or opens (sqlglot/__main__.py, the CLI) cannot
# change any test's outcome (Selector.python_file).
UNRUN = os.environ.get("BR_UNRUN", "1") == "1"


def log(*args) -> None:
    print(*args, file=sys.stderr)


# --------------------------------------------------------------------------- map


class Map:
    FIELDS = ("tests", "sets", "lines", "import_lines", "reads", "classes", "names", "import_names", "tests_by_file")

    def __init__(self, path: Path) -> None:
        import gzip

        with gzip.open(path, "rt") as f:
            raw = json.load(f)
        self.tests: list[str] = raw["tests"]
        self.sets: list[list[int]] = raw["sets"]
        self.lines = {f: dict(pairs) for f, pairs in raw["lines"].items()}
        self.import_lines = {f: set(ls) for f, ls in raw["import_lines"].items()}
        self.reads: dict[str, int] = raw["reads"]
        self.classes: dict[str, int] = raw["classes"]
        self.names: dict[str, int] = raw["names"]
        self.import_names: set[str] = set(raw.get("import_names", ()))
        self.tests_by_file: dict[str, set[int]] = {}
        for i, nodeid in enumerate(self.tests):
            self.tests_by_file.setdefault(nodeid.split("::", 1)[0], set()).add(i)
        self.load_reads: set[str] | None = None  # load_read_names(), made when first needed
        self.load_reads_text: str | None = None  # or from the marshal copy, one name per line

    @staticmethod
    def cache_path(path: Path) -> Path:
        return path.parent / (path.name.split(".", 1)[0] + ".marshal")

    @classmethod
    def load(cls, path: Path) -> "Map":
        """The map from its marshal copy, made at image build time (the build is not
        charged; reading it is several times faster than gzip + JSON), when that copy
        was made from this very file. Otherwise from the JSON."""
        try:
            data = path.read_bytes()
            raw = marshal.loads(cls.cache_path(path).read_bytes())  # load(file) reads in tiny pieces: far slower
            if raw["source"] == (len(data), zlib.crc32(data)):
                m = cls.__new__(cls)
                for k in cls.FIELDS:
                    setattr(m, k, raw[k])
                m.load_reads = None
                m.load_reads_text = raw.get("load_reads")
                return m
        except Exception:
            pass
        return cls(path)

    def save_cache(self, path: Path) -> None:
        data = path.read_bytes()
        raw = {k: getattr(self, k) for k in self.FIELDS}
        raw["source"] = (len(data), zlib.crc32(data))
        if SRC.is_dir():  # one string: unmarshalling a set of 5600 names costs every run 1 ms
            raw["load_reads"] = "\n".join(sorted(self.load_read_names()))
        self.cache_path(path).write_bytes(marshal.dumps(raw))

    def load_read_names(self) -> set[str]:
        """Names that code run while modules load reads in ways the name index does not
        follow to the tests that depend on it (build_map.py's spelling: names, attributes,
        identifier strings), over sqlglot/ and tests/ of the pinned source:
        - each function body that ran at import (import_lines; a def line runs for every def,
          so the body's lines decide) reads its refs, and stores what it builds anywhere;
        - each module or class body statement that is not an assignment, import or def (a
          call, loop, `if`, `with`), and each decorator and class header, reads its refs;
        - in module and class body assignments, def defaults and annotations, the names
          evaluation acts on rather than only stores (_acted_on: calls, subscripts, unpacking,
          operators, attribute bases, hashing, iteration, f-strings; also the base of a mutated
          `X[k] =`, `X.a =`, `X +=`): a new value there can raise while the module loads
          (DuckDBGenerator parses an f-string of RANDSTR_CHAR_POOL, BigQueryGenerator
          subscripts AFTER_HAVING_MODIFIER_TRANSFORMS["qualify"]);
        - an assignment, in a module or class body, of a name read so reads its right side
          too, transitively (T = build(X) with T read so: X is read so). Select spreads
          QUERY_MODIFIERS into its arg_types, which generators/duckdb.py's template parse reads
          at import: work/sets/mcset (br-6) has 23 flips of it that break 34 test files.
        The index follows the rest: functions run in tests, class bodies (their users) and
        module-level assignments (their dependents)."""
        if self.load_reads is not None:
            return self.load_reads
        if self.load_reads_text is not None:
            self.load_reads = set(self.load_reads_text.split("\n"))
            return self.load_reads
        import bisect

        out: set[str] = set()
        assigns: list[tuple[set[str], set[str]]] = []
        for root in ("sqlglot", "tests"):
            for p in sorted((SRC / root).rglob("*.py")):
                rel = p.relative_to(SRC).as_posix()
                try:
                    tree = ast.parse(p.read_text(encoding="utf-8"))
                except (SyntaxError, ValueError, OSError):
                    continue
                ran = sorted(self.import_lines.get(rel, ()))
                for node in ast.walk(tree):
                    if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                        i = bisect.bisect_left(ran, node.body[0].lineno)
                        if i < len(ran) and ran[i] <= (node.end_lineno or node.lineno):
                            out |= refs_of(node)
                _load_statements(tree.body, out, assigns)
        changed = True
        while changed:
            changed = False
            for defined, used in assigns:
                if defined & out and not used <= out:
                    out |= used
                    changed = True
        self.load_reads = out
        return out

    def line_tests(self, path: str, start: int, end: int) -> set[int]:
        by_line = self.lines.get(path, {})
        out: set[int] = set()
        for ln in range(start, end + 1):
            s = by_line.get(ln)
            if s is not None:
                out.update(self.sets[s])
        return out

    def ran_at_import(self, path: str, start: int, end: int) -> bool:
        lines = self.import_lines.get(path, ())
        return any(ln in lines for ln in range(start, end + 1))

    def never_used(self, path: str) -> bool:
        """No line of the file ran, at import or in a test, and no test opened it."""
        return not self.lines.get(path) and not self.import_lines.get(path) and path not in self.reads

    def set_of(self, table: dict[str, int], key: str) -> set[int] | None:
        s = table.get(key)
        return None if s is None else set(self.sets[s])


# ------------------------------------------------------------------------- patch


class FilePatch:
    def __init__(self) -> None:
        self.old_path: str | None = None
        self.new_path: str | None = None
        self.hunks: list[tuple[int, list[str]]] = []  # (old_start, lines with their +/-/space prefix)
        self.binary = False

    @property
    def path(self) -> str:
        return self.old_path or self.new_path or ""


HUNK_RE = re.compile(r"^@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@")
_C_ESCAPES = {"a": 7, "b": 8, "t": 9, "n": 10, "v": 11, "f": 12, "r": 13, '"': 34, "\\": 92}


def unquote_path(s: str) -> tuple[str, str] | None:
    """A path git wrote C-quoted (it does for '"', '\\', control and non-ASCII bytes):
    (the path, the text after the closing quote), or None when s does not start with one."""
    if not s.startswith('"'):
        return None
    out = bytearray()
    i = 1
    while i < len(s):
        c = s[i]
        if c == '"':
            return out.decode("utf-8", "surrogateescape"), s[i + 1:]
        if c == "\\" and i + 1 < len(s):
            octal = re.match(r"[0-7]{1,3}", s[i + 1:i + 4])
            if octal:
                out.append(int(octal.group(), 8) & 0xFF)
                i += 1 + len(octal.group())
                continue
            out.append(_C_ESCAPES.get(s[i + 1], ord(s[i + 1]) & 0xFF))
            i += 2
            continue
        out += c.encode("utf-8", "surrogateescape")
        i += 1
    return None


def header_path(s: str) -> str:
    """The path in a '--- ' / '+++ ' line, without the tab and timestamp some diffs add."""
    q = unquote_path(s)
    return q[0] if q else s.split("\t")[0].strip()


def git_line_paths(rest: str) -> tuple[str, str] | None:
    """Both paths of a 'diff --git ' line when git quoted one or both of them."""
    first = unquote_path(rest)
    if first:
        a, tail = first
        tail = tail[1:] if tail.startswith(" ") else tail
    else:
        cut = rest.find(' "')
        if cut < 0:
            return None
        a, tail = rest[:cut], rest[cut + 1:]
    second = unquote_path(tail)
    b = second[0] if second else tail
    if a.startswith("a/") and b.startswith("b/"):
        return a[2:], b[2:]
    return None


def parse_patch(text: str) -> list[FilePatch]:
    """Parse a unified diff. Hunk bodies are read by the counts in their @@ header,
    so a removed line that itself starts with "--" or "++" is never taken for a header."""
    files: list[FilePatch] = []
    cur: FilePatch | None = None
    hunk: list[str] | None = None
    left_old = left_new = 0
    for line in text.split("\n"):
        if hunk is not None and (left_old > 0 or left_new > 0):
            tag = line[:1]
            if tag == "\\":
                continue  # "\ No newline at end of file"
            if tag == " " or line == "":
                hunk.append(" " + line[1:])
                left_old -= 1
                left_new -= 1
                continue
            if tag == "-":
                hunk.append(line)
                left_old -= 1
                continue
            if tag == "+":
                hunk.append(line)
                left_new -= 1
                continue
            raise PatchError("malformed hunk")
        hunk = None
        if line.startswith("diff --git "):
            cur = FilePatch()
            files.append(cur)
            m = re.match(r"diff --git a/(.*) b/(.*)$", line)
            if m:
                cur.old_path, cur.new_path = m.group(1), m.group(2)
            elif '"' in line:
                cur.old_path, cur.new_path = git_line_paths(line[len("diff --git "):]) or (None, None)
            continue
        if line.startswith("--- ") and (cur is None or cur.hunks):
            # a diff without "diff --git" lines (diff -u): each file starts at its "--- "
            cur = FilePatch()
            files.append(cur)
        elif cur is None:
            continue
        if line.startswith("--- "):
            p = header_path(line[4:])
            cur.old_path = None if p == "/dev/null" else p[2:] if p.startswith("a/") else p
        elif line.startswith("+++ "):
            p = header_path(line[4:])
            cur.new_path = None if p == "/dev/null" else p[2:] if p.startswith("b/") else p
        elif line.startswith("new file mode"):
            cur.old_path = None
        elif line.startswith("deleted file mode"):
            cur.new_path = None
        elif line.startswith("rename from "):
            p = line[len("rename from "):]
            cur.old_path = (unquote_path(p) or (p,))[0]
        elif line.startswith("rename to "):
            p = line[len("rename to "):]
            cur.new_path = (unquote_path(p) or (p,))[0]
        elif line.startswith("Binary files") or line.startswith("GIT binary patch"):
            cur.binary = True
        else:
            m = HUNK_RE.match(line)
            if m:
                hunk = []
                cur.hunks.append((int(m.group(1)), hunk))
                left_old = int(m.group(2)) if m.group(2) is not None else 1
                left_new = int(m.group(4)) if m.group(4) is not None else 1
    return files


class PatchError(Exception):
    pass


def apply_hunks(old_lines: list[str], hunks) -> list[str]:
    """Apply unified-diff hunks to a file's lines (without newlines)."""
    new: list[str] = []
    pos = 0  # 0-based index into old_lines
    for old_start, body in hunks:
        start = max(old_start - 1, 0)
        if not any(l[:1] in (" ", "-") for l in body):
            start = old_start  # pure insertion: "-N,0" means after line N
        if start < pos:
            raise PatchError("overlapping hunks")
        new.extend(old_lines[pos:start])
        pos = start
        for l in body:
            tag, text = l[:1], l[1:]
            if tag == "+":
                new.append(text)
                continue
            if pos >= len(old_lines) or old_lines[pos] != text:
                raise PatchError("context mismatch")
            if tag == " ":
                new.append(text)
            pos += 1
    new.extend(old_lines[pos:])
    return new


def hunk_changes(old_start: int, body: list[str]) -> tuple[list[int], list[int]]:
    """Old line numbers removed, and old line numbers that pure insertions follow.

    Added lines that replace removed lines (a "-" run followed by a "+" run) are
    placed by the removed lines; only "+" runs with no "-" run right before them
    count as insertions.
    """
    removed, inserted_after = [], []
    ln = old_start if any(l[:1] in (" ", "-") for l in body) else old_start + 1
    prev = " "
    for l in body:
        tag = l[:1]
        if tag == "-":
            removed.append(ln)
            ln += 1
        elif tag == " ":
            ln += 1
        elif tag == "+" and prev == " ":
            inserted_after.append(ln - 1)
        if tag != "+":
            prev = tag
    return removed, sorted(set(inserted_after))


# ------------------------------------------------------------------- python ast


_COMPILED: dict[str, list] = {}
_MISSING = object()


def _code_list(src: str) -> list | None:
    """Every code object of a module, in a fixed order, keyed by its source text."""
    found = _COMPILED.get(src)
    if found is None:
        try:
            top = compile(src, "<m>", "exec", dont_inherit=True)
        except (SyntaxError, ValueError):
            return None
        found, stack = [], [top]
        while stack:
            co = stack.pop()
            found.append(co)
            stack.extend(c for c in reversed(co.co_consts) if isinstance(c, types.CodeType))
        _COMPILED[src] = found
    return found


def const_key(c):
    """A constant's identity by exact type and value, all the way down.

    Plain == is not enough: (0,) == (False,), (1, 2) == (1, 2.0) and 0.0 == -0.0 are
    all True in Python, yet each pair behaves differently. Containers are compared
    element by element with their types; floats and complex numbers by repr."""
    if isinstance(c, types.CodeType):
        return "<code>"
    t = type(c)
    if t is tuple:
        return ("tuple", tuple(const_key(x) for x in c))
    if t is frozenset:
        return ("frozenset", frozenset(const_key(x) for x in c))
    if t in (float, complex):
        return (t.__name__, repr(c))
    return (t.__name__, repr(c) if t not in (int, str, bytes, bool, type(None), type(...)) else c)


def _behavior(co):
    """What a code object does, ignoring line numbers (comments move lines around).

    Python 3.13 stores a class's first line as a constant in its body
    (__firstlineno__, used only by introspection), so that constant is ignored too."""
    class_line = co.co_firstlineno if "__firstlineno__" in co.co_names else None
    consts = tuple(
        "<firstlineno>" if type(c) is int and c == class_line
        else const_key(c)
        for c in co.co_consts
    )
    return (
        co.co_name, co.co_qualname, co.co_code, co.co_names, co.co_varnames, co.co_freevars,
        co.co_cellvars, consts, co.co_flags, co.co_argcount, co.co_kwonlyargcount, co.co_posonlyargcount,
    )


def same_tree(a: str, b: str) -> bool:
    """True when two sources compile to the same code (comments, spacing, redundant
    parentheses: Trivial Compiler Equivalence). Docstrings are constants, so a
    docstring edit is a real change here."""
    x, y = _behaviors(a), _code_list(b)
    if x is None or y is None or len(x) != len(y):
        return False
    return all(p == _behavior(q) for p, q in zip(x, y))


BEHAVIOR_DIR = Path(os.environ.get("BR_BEHAVIOR", APP / "maps" / "behavior"))
_BEHAVIORS: dict[str, list | None] = {}


def _source_key(src: str) -> tuple[int, int, int]:
    return len(src), zlib.crc32(src.encode("utf-8", "surrogatepass")), sys.flags.optimize


def _behavior_file(key: tuple[int, int, int]) -> Path:
    return BEHAVIOR_DIR / f"{key[0]}-{key[1]:08x}.marshal"


def _behaviors(src: str) -> list | None:
    """_behavior of each of a source's code objects (None: it does not compile).
    The pinned files' lists are written at image build time (save_behaviors), so a
    run need not compile them; a list is used only if made from this very text."""
    found = _BEHAVIORS.get(src, _MISSING)
    if found is _MISSING:
        key = _source_key(src)
        try:
            stored_key, found = marshal.loads(_behavior_file(key).read_bytes())
            if stored_key != key:
                raise ValueError
        except Exception:
            codes = _code_list(src)
            found = None if codes is None else [_behavior(c) for c in codes]
        _BEHAVIORS[src] = found
    return found


def save_behaviors(src_root: Path) -> None:
    """Image build time: the behaviors of every Python file in the pinned source,
    one file each, named by its text's length and crc32 (texts sharing a name: none)."""
    BEHAVIOR_DIR.mkdir(parents=True, exist_ok=True)
    seen: dict[tuple, str | None] = {}
    for p in sorted(src_root.rglob("*.py")):
        try:
            src = p.read_text(encoding="utf-8")
        except (OSError, ValueError):
            continue
        key = _source_key(src)
        seen[key] = src if seen.get(key, src) == src else None
    for key, src in seen.items():
        if src is not None:
            codes = _code_list(src)
            _COMPILED.pop(src, None)
            found = None if codes is None else [_behavior(c) for c in codes]
            _behavior_file(key).write_bytes(marshal.dumps((key, found)))


IDENT_RE = re.compile(r"[A-Za-z_][A-Za-z0-9_]*")
NON_ASCII_WORD_RE = re.compile(r"[0-9A-Za-z_]*[^\x00-\x7f][0-9A-Za-z_\x80-\U0010ffff]*")
_NFKC_STABLE: dict[str, bool] = {}


def adds_new_name(body: list[str], old: str) -> bool:
    """Whether a hunk may add an identifier that is nowhere in the old source.

    only_adds_new_functions needs a new function whose name is not in the old source.
    A name never spans lines, and each line of the patched file is an old line or an
    added one, so without such a name on an added line its answer is no and the
    patched file need not be parsed. Names are NFKC-normalized, so non-ASCII added
    lines, or old non-ASCII names that normalize to something else, take the full check."""
    for l in body:
        if l[:1] != "+":
            continue
        text = l[1:]
        if not text.isascii():
            return True
        if any(name not in old for name in IDENT_RE.findall(text)):
            return True
    return not old.isascii() and not _nfkc_stable(old)


def _nfkc_stable(src: str) -> bool:
    """Whether every identifier the tokenizer could read in src is already NFKC-normal."""
    found = _NFKC_STABLE.get(src)
    if found is None:
        found = True
        for word in NON_ASCII_WORD_RE.findall(src):
            # a name is a run of identifier characters
            chars = "".join(c if c.isascii() or ("a" + c).isidentifier() else " " for c in word)
            for run in chars.split(" "):
                if not run.isascii() and not all(
                    unicodedata.is_normalized("NFKC", run[i:j])
                    for i in range(len(run))
                    for j in range(i + 1, len(run) + 1)
                ):
                    found = False
        _NFKC_STABLE[src] = found
    return found


_PARSED: dict[str, tuple[ast.Module, list[str]] | None] = {}


def _parse(src: str, keep: bool = False) -> tuple[ast.Module, list[str]] | None:
    """A module's syntax tree and its lines. keep=True: parse this source once per run
    (the pinned files; patched variants are parsed when needed and not kept)."""
    found = _PARSED.get(src, _MISSING)
    if found is _MISSING:
        try:
            found = (ast.parse(src), src.split("\n"))
        except SyntaxError:
            found = None
        if keep:
            _PARSED[src] = found
    return found


def _same_text(x: ast.stmt, lx: list[str], y: ast.stmt, ly: list[str]) -> bool:
    """Same source text, decorators included: then the syntax trees are the same too."""
    if x.col_offset != y.col_offset or x.end_col_offset != y.end_col_offset:
        return False
    fx, fy = x.lineno, y.lineno
    for d in getattr(x, "decorator_list", ()):
        fx = min(fx, d.lineno)
    for d in getattr(y, "decorator_list", ()):
        fy = min(fy, d.lineno)
    ex, ey = x.end_lineno, y.end_lineno
    return ex - fx == ey - fy and lx[fx - 1:ex] == ly[fy - 1:ey]


def same_node(x, lx: list[str], y, ly: list[str]) -> bool:
    """ast.dump(x) == ast.dump(y), without building the dumps.

    The dump shows a node's class and its fields (None and [] left out), and leaves
    by repr; positions are not in it. So: compare structurally, leaves by repr, and
    take statements with identical source text as equal without walking them."""
    if isinstance(x, ast.AST):
        if type(y) is not type(x):
            return False
        if isinstance(x, ast.stmt) and _same_text(x, lx, y, ly):
            return True
        return all(
            same_node(getattr(x, f, _MISSING), lx, getattr(y, f, _MISSING), ly) for f in x._fields
        )
    if isinstance(x, list):
        return (
            isinstance(y, list) and len(x) == len(y)
            and all(same_node(p, lx, q, ly) for p, q in zip(x, y))
        )
    return not isinstance(y, (ast.AST, list)) and repr(x) == repr(y)


class Stmt:
    __slots__ = ("node", "start", "end", "func", "cls", "parent")

    def __init__(self, node, func, cls, parent) -> None:
        self.node = node
        self.start = node.lineno
        self.end = node.end_lineno or node.lineno
        self.func = func  # innermost enclosing function node, or None
        self.cls = cls  # dotted class path inside the module, or None
        self.parent = parent


def index_statements(tree: ast.Module) -> list[Stmt]:
    out: list[Stmt] = []

    def visit(body, func, cls, parent) -> None:
        for node in body:
            if not isinstance(node, ast.stmt):
                continue
            s = Stmt(node, func, cls, parent)
            out.append(s)
            if isinstance(node, ast.ClassDef):
                inner_cls = f"{cls}.{node.name}" if cls else node.name
                visit(node.body, func, inner_cls, s)
            elif isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                visit(node.body, node, cls, s)
            else:
                for field in ("body", "orelse", "finalbody", "handlers"):
                    child = getattr(node, field, None)
                    if isinstance(child, list):
                        kids = []
                        for c in child:
                            if isinstance(c, ast.ExceptHandler):
                                kids.extend(c.body)
                            else:
                                kids.append(c)
                        visit(kids, func, cls, s)
                if isinstance(node, ast.Match):
                    for case in node.cases:
                        visit(case.body, func, cls, s)

    visit(tree.body, None, None, None)
    return out


def innermost(stmts: list[Stmt], lo: int, hi: int) -> Stmt | None:
    best = None
    for s in stmts:
        if s.start <= lo and hi <= s.end and (best is None or s.end - s.start <= best.end - best.start):
            best = s
    return best


def module_name(path: str) -> str:
    mod = path[:-3].replace("/", ".")
    return mod[: -len(".__init__")] if mod.endswith(".__init__") else mod


LOADVAL_FALLBACK_NAMES = ("arg_types", "is_var_len_args")


def _watched_values(src: str, quals: dict | None, consts: dict | None) -> dict | None:
    """{("class", qualname, name): [value of each assignment to name in its body]} for the
    classes in quals and the names each is watched for (all classes, LOADVAL_FALLBACK_NAMES,
    when quals is None), and {("const", name, ""): [module-level statements naming it]} for
    the dicts in consts (every module-level assignment when quals is None); None when src
    does not parse."""
    try:
        tree = ast.parse(src)
    except SyntaxError:
        return None
    out: dict[tuple[str, str, str], list[ast.AST]] = {}

    def assigns(stmt: ast.stmt) -> list[ast.expr]:
        if isinstance(stmt, ast.Assign):
            return stmt.targets
        if isinstance(stmt, (ast.AnnAssign, ast.AugAssign)):
            return [stmt.target]
        return []

    def walk(body: list[ast.stmt], prefix: str) -> None:
        for stmt in body:
            if isinstance(stmt, ast.ClassDef):
                q = f"{prefix}{stmt.name}"
                names = LOADVAL_FALLBACK_NAMES if quals is None else (quals.get(q) or {}).get("names", ())
                for name in names:
                    out[("class", q, name)] = [
                        s.value for s in stmt.body
                        if any(isinstance(t, ast.Name) and t.id == name for t in assigns(s)) and s.value is not None
                    ]
                walk(stmt.body, q + ".")
            elif not prefix and not isinstance(stmt, (ast.FunctionDef, ast.AsyncFunctionDef)):
                if quals is None:
                    for t in assigns(stmt):
                        if isinstance(t, ast.Name):
                            out.setdefault(("const", t.id, ""), []).append(stmt)
                elif consts:
                    # the definition, and any later `NAME[k] = v` or `NAME.update(...)`
                    for name in {n.id for n in ast.walk(stmt) if isinstance(n, ast.Name)} & set(consts):
                        out.setdefault(("const", name, ""), []).append(stmt)

    walk(tree.body, "")
    return out


def _adds_optional_keys(a: ast.expr, b: ast.expr, info: dict) -> bool:
    """b is the dict literal a plus new string keys with constant false values (an optional
    argument nothing sets yet: no required key, no unexpected key, nothing a load-time
    validation can see), and where a Func takes the literal (from_arg_list maps arguments
    by position) only at its end, the literal being the class's whole dict, with no var-len key."""
    if not (isinstance(a, ast.Dict) and isinstance(b, ast.Dict)):
        return False
    old = list(zip(a.keys, a.values))
    have = {k.value for k, _ in old if isinstance(k, ast.Constant)}
    i, added = 0, []
    for j, (k, v) in enumerate(zip(b.keys, b.values)):
        if i < len(old) and ast.dump(old[i][1]) == ast.dump(v) and (
            (old[i][0] is None and k is None) or (old[i][0] is not None and k is not None and ast.dump(old[i][0]) == ast.dump(k))
        ):
            i += 1
            continue
        if not (
            isinstance(k, ast.Constant) and isinstance(k.value, str) and k.value not in have
            and isinstance(v, ast.Constant) and not v.value
        ):
            return False
        have.add(k.value)
        added.append(j)
    if i != len(old) or not added:
        return False
    if info.get("positional"):
        return not info.get("varlen") and not info.get("inner") and added == list(range(len(old), len(b.keys)))
    return True


def defined_names(node: ast.stmt) -> set[str]:
    if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
        return {node.name}
    names = set()
    targets = getattr(node, "targets", None) or [getattr(node, "target", None)]
    for t in targets:
        if t is not None:
            names |= {n.id for n in ast.walk(t) if isinstance(n, ast.Name)}
    return names


def refs_of(node: ast.AST) -> set[str]:
    """Names code may read, by spelling (build_map.py's refs_of): plain names, attributes
    and identifier-like strings (getattr(obj, "NAME"))."""
    refs = set()
    for sub in ast.walk(node):
        if isinstance(sub, ast.Name):
            refs.add(sub.id)
        elif isinstance(sub, ast.Attribute):
            refs.add(sub.attr)
        elif isinstance(sub, ast.Constant) and isinstance(sub.value, str) and sub.value.isidentifier():
            refs.add(sub.value)
    return refs


def _refs_run(node: ast.AST) -> set[str]:
    """refs_of, without lambda bodies (they do not run where the lambda is made)."""
    refs: set[str] = set()
    todo = [node]
    while todo:
        n = todo.pop()
        if isinstance(n, ast.Lambda):
            todo.extend(d for d in n.args.defaults + n.args.kw_defaults if d is not None)
            continue
        if isinstance(n, ast.Name):
            refs.add(n.id)
        elif isinstance(n, ast.Attribute):
            refs.add(n.attr)
        elif isinstance(n, ast.Constant) and isinstance(n.value, str) and n.value.isidentifier():
            refs.add(n.value)
        todo.extend(ast.iter_child_nodes(n))
    return refs


def _acted_on(node: ast.AST | None, out: set[str]) -> None:
    """Add the names whose values evaluating `node` acts on, where a new value can raise:
    callees and arguments, subscript bases and keys, `*`/`**` operands, operands of
    arithmetic, unary and comparison operators, attribute bases, dict keys and set elements
    (hashed), comprehension iterables and f-string parts. Not names it only stores (a bare
    value, container elements, dict values), nor lambda bodies. Each node is visited once:
    an acted-on part gives all its names and is not searched again."""
    if node is None:
        return
    todo = [node]
    while todo:
        n = todo.pop()
        if isinstance(n, ast.Lambda):
            todo.extend(d for d in n.args.defaults + n.args.kw_defaults if d is not None)
        elif isinstance(n, (ast.Call, ast.Subscript, ast.Starred, ast.Attribute, ast.FormattedValue,
                            ast.BinOp, ast.Compare, ast.Set)) or (
            isinstance(n, ast.UnaryOp) and not isinstance(n.op, ast.Not)
        ):
            out |= _refs_run(n)
        elif isinstance(n, ast.Dict):
            for k, v in zip(n.keys, n.values):
                if k is None:
                    out |= _refs_run(v)
                else:
                    out |= _refs_run(k)
                    todo.append(v)
        elif isinstance(n, ast.comprehension):
            out |= _refs_run(n.iter)
            todo.extend(n.ifs)
        else:
            todo.extend(ast.iter_child_nodes(n))


def _load_statements(body: list, out: set[str], assigns: list) -> None:
    """Map.load_read_names over statements that run while their module loads (outside defs)."""
    for st in body:
        if isinstance(st, (ast.Import, ast.ImportFrom)):
            continue
        if isinstance(st, (ast.FunctionDef, ast.AsyncFunctionDef)):
            for d in st.decorator_list:
                out |= refs_of(d)
            a = st.args
            for d in a.defaults + [x for x in a.kw_defaults if x is not None]:
                _acted_on(d, out)
            for x in a.posonlyargs + a.args + a.kwonlyargs + [a.vararg, a.kwarg]:
                if x is not None:
                    _acted_on(x.annotation, out)
            _acted_on(st.returns, out)
            continue
        if isinstance(st, ast.ClassDef):
            for part in st.decorator_list + st.bases + st.keywords:
                out |= refs_of(part)
            _load_statements(st.body, out, assigns)
            continue
        if isinstance(st, (ast.Assign, ast.AnnAssign, ast.AugAssign)):
            targets = st.targets if isinstance(st, ast.Assign) else [st.target]
            for t in targets:
                if isinstance(t, ast.Name):
                    if isinstance(st, ast.AugAssign):
                        out.add(t.id)  # `X op= v` acts on X
                elif isinstance(t, (ast.Subscript, ast.Attribute)):
                    out |= _refs_run(t.value)  # `X[k] = v`, `X.a = v` mutate X
                    _acted_on(t, out)
                elif st.value is not None:
                    out |= _refs_run(st.value)  # unpacking acts on the value
            if isinstance(st, ast.AnnAssign):
                _acted_on(st.annotation, out)
            if st.value is not None:
                if isinstance(st, ast.AugAssign):
                    out |= _refs_run(st.value)
                _acted_on(st.value, out)
                assigns.append((defined_names(st), refs_of(st.value)))
            continue
        inner: list = []
        for field, value in ast.iter_fields(st):
            for x in value if isinstance(value, list) else [value]:
                if isinstance(x, (ast.excepthandler, ast.match_case)):
                    for f, v in ast.iter_fields(x):
                        if f != "body" and isinstance(v, ast.AST):
                            out |= refs_of(v)
                    inner += x.body
                elif isinstance(x, ast.stmt):
                    inner.append(x)
                elif isinstance(x, ast.AST):
                    out |= refs_of(x)
        _load_statements(inner, out, assigns)


_COOKIE = re.compile(r"^[ \t\f]*#.*?coding[:=]")


def encoding_change(old: str, new: str) -> str | None:
    """Why the patched file's bytes would not load as the text we compare, or None.

    Python decodes a module by the coding cookie of its first two lines (PEP 263), which
    compile() of a str ignores: `# coding: ascii` added to a file with any non-ASCII byte,
    or an unknown encoding, makes the import raise SyntaxError; latin-1 changes its strings.
    """
    heads = [x.split("\n", 2)[:2] for x in (old, new)]
    if heads[0] == heads[1] or not any(_COOKIE.match(ln) for h in heads for ln in h):
        return None
    import io
    import tokenize

    raw = new.encode("utf-8")
    try:
        enc, _ = tokenize.detect_encoding(io.BytesIO(raw).readline)
        text = raw.decode(enc)
    except (SyntaxError, LookupError, UnicodeDecodeError):
        return "coding cookie: the import cannot decode the file"
    if text.lstrip("\ufeff") != new.lstrip("\ufeff"):
        return f"coding cookie {enc}: the file decodes to other text"
    return None


_IDENT = re.compile(r"(?<![0-9A-Za-z_])[A-Za-z_][0-9A-Za-z_]*")
_STR_OR_COMMENT = re.compile(r"#.*$|'(?:\\.|[^'\\])*'|\"(?:\\.|[^\"\\])*\"")


def names_or_order_change(hunks: list[tuple[int, list[str]]]) -> bool:
    """Whether a file's hunks change which names its code mentions, or move a line: the
    only ways a patch can make module code load a name before anything binds it (a typo,
    a rename or deletion, a statement moved above the one that binds what it reads). A
    token flip of an operator, keyword or number, sqlglot's usual change, does neither,
    so it skips import_breaks, which costs a parse of the patched file."""
    from collections import Counter
    import keyword

    names = {"-": Counter(), "+": Counter()}
    lines = {"-": Counter(), "+": Counter()}
    for _, body in hunks:
        for line in body:
            sign = line[:1]
            if sign not in names:
                continue
            text = line[1:]
            names[sign].update(w for w in _IDENT.findall(_STR_OR_COMMENT.sub(" ", text)) if not keyword.iskeyword(w))
            stripped = text.strip()
            if stripped and not stripped.startswith("#"):
                lines[sign][stripped] += 1
    return names["-"] != names["+"] or bool(lines["-"] & lines["+"])


_ALWAYS_BOUND = frozenset(dir(builtins)) | {
    "__name__", "__file__", "__doc__", "__spec__", "__package__", "__loader__", "__builtins__",
    "__path__", "__annotations__", "__cached__", "__module__", "__qualname__",
}


def import_time_names(tree: ast.Module) -> tuple[set[str], set[str], bool]:
    """(names loaded before anything binds them, names the module binds, has a star import)
    for the code a module runs while it loads: its statements and class bodies in order,
    with the decorators, defaults and bases of their defs and classes (annotations only
    without `from __future__ import annotations`), not function or lambda bodies.

    Approximate on purpose (a name bound in one branch of an `if` counts as bound after
    it, TYPE_CHECKING imports count, a comprehension's targets count for all of it), so
    use the difference between a patched module and the pinned one, which loads: a name
    only the patched one loads unbound is a NameError while the module loads."""
    lazy = any(
        isinstance(n, ast.ImportFrom) and n.module == "__future__" and any(a.name == "annotations" for a in n.names)
        for n in tree.body
    )
    unbound: set[str] = set()
    star = False

    def expr(node: ast.AST | None, glob: set[str], local: set[str]) -> None:
        if node is None:
            return
        extra = set()
        todo = [node]
        names = []
        while todo:
            n = todo.pop()
            if isinstance(n, ast.Lambda):
                todo.extend(d for d in n.args.defaults + n.args.kw_defaults if d is not None)
                continue
            if isinstance(n, ast.Name):
                if isinstance(n.ctx, ast.Load):
                    names.append(n.id)
                else:
                    extra.add(n.id)  # comprehension targets, := targets
            elif isinstance(n, ast.comprehension):
                extra |= {t.id for t in ast.walk(n.target) if isinstance(t, ast.Name)}
            todo.extend(ast.iter_child_nodes(n))
        for x in names:
            if x not in local and x not in glob and x not in extra and x not in _ALWAYS_BOUND:
                unbound.add(x)

    def bind_targets(t: ast.AST, glob: set[str], local: set[str]) -> None:
        for n in ast.walk(t):
            if isinstance(n, ast.Name):
                if isinstance(n.ctx, ast.Store):
                    local.add(n.id)
                elif n.id not in local and n.id not in glob and n.id not in _ALWAYS_BOUND:
                    unbound.add(n.id)  # x.attr = ... / x[k] = ... loads x
            elif isinstance(n, (ast.Subscript, ast.Attribute)):
                expr(n.slice if isinstance(n, ast.Subscript) else None, glob, local)

    def run(body: list[ast.stmt], glob: set[str], local: set[str]) -> None:
        nonlocal star
        for st in body:
            if isinstance(st, (ast.FunctionDef, ast.AsyncFunctionDef)):
                a = st.args
                for d in st.decorator_list + a.defaults + [x for x in a.kw_defaults if x is not None]:
                    expr(d, glob, local)
                if not lazy:
                    for x in a.posonlyargs + a.args + a.kwonlyargs + [a.vararg, a.kwarg]:
                        expr(x.annotation if x is not None else None, glob, local)
                    expr(st.returns, glob, local)
                local.add(st.name)
            elif isinstance(st, ast.ClassDef):
                for d in st.decorator_list + st.bases + [k.value for k in st.keywords]:
                    expr(d, glob, local)
                run(st.body, glob, set())  # a class body sees module globals, not enclosing classes
                local.add(st.name)
            elif isinstance(st, ast.Import):
                local |= {a.asname or a.name.split(".")[0] for a in st.names}
            elif isinstance(st, ast.ImportFrom):
                star |= any(a.name == "*" for a in st.names)
                local |= {a.asname or a.name for a in st.names if a.name != "*"}
            elif isinstance(st, ast.Assign):
                expr(st.value, glob, local)
                for t in st.targets:
                    bind_targets(t, glob, local)
            elif isinstance(st, ast.AnnAssign):
                expr(st.value, glob, local)
                if not lazy:
                    expr(st.annotation, glob, local)
                if st.value is not None:
                    bind_targets(st.target, glob, local)
            elif isinstance(st, ast.AugAssign):
                expr(st.value, glob, local)
                if isinstance(st.target, ast.Name):
                    expr(ast.Name(st.target.id, ast.Load()), glob, local)
                bind_targets(st.target, glob, local)
            elif isinstance(st, (ast.If, ast.While)):
                expr(st.test, glob, local)
                run(st.body, glob, local)
                run(st.orelse, glob, local)
            elif isinstance(st, (ast.For, ast.AsyncFor)):
                expr(st.iter, glob, local)
                bind_targets(st.target, glob, local)
                run(st.body, glob, local)
                run(st.orelse, glob, local)
            elif isinstance(st, (ast.With, ast.AsyncWith)):
                for it in st.items:
                    expr(it.context_expr, glob, local)
                    if it.optional_vars is not None:
                        bind_targets(it.optional_vars, glob, local)
                run(st.body, glob, local)
            elif isinstance(st, ast.Try) or type(st).__name__ == "TryStar":
                run(st.body, glob, local)
                for h in st.handlers:
                    expr(h.type, glob, local)
                    if h.name:
                        local.add(h.name)
                    run(h.body, glob, local)
                run(st.orelse, glob, local)
                run(st.finalbody, glob, local)
            elif isinstance(st, (ast.Global, ast.Nonlocal, ast.Pass, ast.Break, ast.Continue, ast.Delete)):
                pass
            elif isinstance(st, (ast.Expr, ast.Assert, ast.Raise, ast.Return)):
                for c in ast.iter_child_nodes(st):
                    expr(c, glob, local)
            else:  # match, type aliases: bind every stored name, check nothing
                local |= {n.id for n in ast.walk(st) if isinstance(n, ast.Name) and isinstance(n.ctx, ast.Store)}
                local |= {n.name for n in ast.walk(st) if isinstance(getattr(n, "name", None), str)}

    glob: set[str] = set()
    run(tree.body, glob, glob)
    return unbound, glob, star


def import_time_refs(tree: ast.Module) -> tuple[set[str], set[str], set[str]]:
    """(names imported by `from x import name` anywhere, attribute names read and names
    loaded by code that runs while the module loads) of a module."""
    imported = {a.name for n in ast.walk(tree) if isinstance(n, ast.ImportFrom) for a in n.names}
    attrs: set[str] = set()
    loads: set[str] = set()
    todo: list[ast.AST] = list(tree.body)
    while todo:
        n = todo.pop()
        if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef)):
            a = n.args
            todo.extend(n.decorator_list + a.defaults + [x for x in a.kw_defaults if x is not None])
            continue
        if isinstance(n, ast.Lambda):
            todo.extend(d for d in n.args.defaults + n.args.kw_defaults if d is not None)
            continue
        if isinstance(n, ast.Attribute):
            attrs.add(n.attr)
        elif isinstance(n, ast.Name) and isinstance(n.ctx, ast.Load):
            loads.add(n.id)
        todo.extend(ast.iter_child_nodes(n))
    return imported, attrs, loads


def load_attr_reads(tree: ast.Module) -> set[tuple[str | None, str]]:
    """(base name or None, attribute) for each attribute that code run while the module
    loads reads (import_time_refs' walk: not function or lambda bodies, not annotations)."""
    out: set[tuple[str | None, str]] = set()
    todo: list[ast.AST] = list(tree.body)
    while todo:
        n = todo.pop()
        if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef)):
            a = n.args
            todo.extend(n.decorator_list + a.defaults + [x for x in a.kw_defaults if x is not None])
            continue
        if isinstance(n, ast.Lambda):
            todo.extend(d for d in n.args.defaults + n.args.kw_defaults if d is not None)
            continue
        if isinstance(n, ast.AnnAssign):
            todo.extend(x for x in (n.target, n.value) if x is not None)
            continue
        if isinstance(n, ast.Attribute) and isinstance(n.ctx, ast.Load):
            out.add((n.value.id if isinstance(n.value, ast.Name) else None, n.attr))
        todo.extend(ast.iter_child_nodes(n))
    return out


def load_calls(tree: ast.Module) -> list[ast.Call]:
    """The calls that code run while the module loads makes (load_attr_reads' walk)."""
    out: list[ast.Call] = []
    todo: list[ast.AST] = list(tree.body)
    while todo:
        n = todo.pop()
        if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef)):
            a = n.args
            todo.extend(n.decorator_list + a.defaults + [x for x in a.kw_defaults if x is not None])
            continue
        if isinstance(n, ast.Lambda):
            todo.extend(d for d in n.args.defaults + n.args.kw_defaults if d is not None)
            continue
        if isinstance(n, ast.AnnAssign):
            todo.extend(x for x in (n.target, n.value) if x is not None)
            continue
        if isinstance(n, ast.Call):
            out.append(n)
        todo.extend(ast.iter_child_nodes(n))
    return out


def call_rejects(call: ast.Call, fn: ast.FunctionDef | ast.AsyncFunctionDef) -> str | None:
    """Why calling the plain def `fn` as `call` raises TypeError, or None (also when a
    starred or ** argument makes it unknown)."""
    if any(isinstance(x, ast.Starred) for x in call.args) or any(k.arg is None for k in call.keywords):
        return None
    a = fn.args
    pos = [x.arg for x in a.posonlyargs + a.args]
    posonly = {x.arg for x in a.posonlyargs}
    kwonly = [x.arg for x in a.kwonlyargs]
    if len(call.args) > len(pos) and a.vararg is None:
        return f"{len(call.args)} positional arguments, which takes {len(pos)}"
    given = set(pos[: len(call.args)])
    for k in call.keywords:
        if k.arg in posonly or (k.arg not in pos and k.arg not in kwonly):
            if a.kwarg is None:
                return f"keyword {k.arg}, which it has no parameter for"
            continue
        if k.arg in given:
            return f"two values for {k.arg}"
        given.add(k.arg)
    required = pos[: len(pos) - len(a.defaults)] + [x.arg for x, d in zip(a.kwonlyargs, a.kw_defaults) if d is None]
    missing = [r for r in required if r not in given]
    if missing:
        return f"no value for {missing[0]}"
    return None


def stdlib_aliases(tree: ast.Module) -> dict[str, str]:
    """{name: module} for each module-level `import x [as name]` of a standard library module."""
    out = {}
    for n in tree.body:
        if isinstance(n, ast.Import):
            for a in n.names:
                if a.name.split(".")[0] in getattr(sys, "stdlib_module_names", ()):
                    out[a.asname or a.name.split(".")[0]] = a.name if a.asname else a.name.split(".")[0]
    return out


def load_time_classes(tree: ast.Module) -> dict[str, list[ast.ClassDef]]:
    """The classes a module creates while it loads (not those inside functions), by
    dotted name within the module, in source order."""
    out: dict[str, list[ast.ClassDef]] = {}
    todo: list[tuple[ast.AST, str]] = [(n, "") for n in tree.body]
    while todo:
        n, prefix = todo.pop(0)
        if isinstance(n, ast.ClassDef):
            q = prefix + n.name
            out.setdefault(q, []).append(n)
            todo.extend((s, q + ".") for s in n.body)
        elif isinstance(n, (ast.If, ast.Try, ast.With, ast.For, ast.While)) or type(n).__name__ == "TryStar":
            for field in ("body", "orelse", "finalbody"):
                todo.extend((s, prefix) for s in getattr(n, field, ()))
            for h in getattr(n, "handlers", ()):
                todo.extend((s, prefix) for s in h.body)
    return out


def slots_problem(c: ast.ClassDef) -> str | None:
    """Why creating class `c` raises because of its __slots__ (an entry that is no
    identifier, or that a class attribute, method or nested class of the same body also
    binds), "computed" for a value that is no literal of strings, "special" for a
    __dict__ or __weakref__ entry (legal unless a base already has one), else None."""
    slots = None
    bound: set[str] = set()
    for s in c.body:
        if isinstance(s, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
            bound.add(s.name)
        elif isinstance(s, (ast.Import, ast.ImportFrom)):
            bound |= {(a.asname or a.name).split(".")[0] for a in s.names}
        elif isinstance(s, (ast.Assign, ast.AnnAssign, ast.AugAssign)):
            if isinstance(s, ast.AnnAssign) and s.value is None:
                continue  # an annotation alone makes no class attribute
            for t in s.targets if isinstance(s, ast.Assign) else [s.target]:
                for n in ast.walk(t):
                    if isinstance(n, ast.Name) and isinstance(n.ctx, ast.Store):
                        if n.id == "__slots__":
                            slots = s.value
                        else:
                            bound.add(n.id)
    if slots is None:
        return None
    if isinstance(slots, ast.Constant) and isinstance(slots.value, str):
        names = [slots.value]
    elif isinstance(slots, (ast.Tuple, ast.List, ast.Set)) and all(
        isinstance(e, ast.Constant) and isinstance(e.value, str) for e in slots.elts
    ):
        names = [e.value for e in slots.elts]
    else:
        return "computed"
    bad = [x for x in names if not x.isidentifier()]
    if bad:
        return f"{c.name}.__slots__ entry {bad[0]!r} is no identifier"
    clash = sorted(set(names) & bound)
    if clash:
        return f"{c.name}.__slots__ entry {clash[0]!r} is also a class attribute"
    if {"__dict__", "__weakref__"} & set(names):
        return "special"
    return None


def class_creation_break(old: ast.Module, new: ast.Module) -> str | None:
    """Why the patched module would raise while it creates a class, where the pinned
    one does not: a __slots__ that type() rejects (TypeError, ValueError), or new bases
    or metaclass, whose method order or instance layout can conflict (TypeError). The
    rules that narrow a class-level change to the class's users assume the class, and so
    its module, still load."""
    def header(c: ast.ClassDef) -> list[str]:
        return [ast.dump(b) for b in c.bases] + [ast.dump(k.value) for k in c.keywords if k.arg == "metaclass"]

    before = load_time_classes(old)
    for q, nodes in load_time_classes(new).items():
        olds = before.get(q, [])
        for i, c in enumerate(nodes):
            o = olds[i] if i < len(olds) else None
            got = slots_problem(c)
            if got in ("computed", "special"):
                # legal as pinned (the pinned module loads): a changed value may not be
                if o is None or _slots_dump(o) != _slots_dump(c):
                    return f"gives {q} a new __slots__ that is " + (
                        "computed" if got == "computed" else "given __dict__ or __weakref__"
                    )
            elif got is not None and (o is None or slots_problem(o) != got):
                return got
            if o is not None and header(c) != header(o):
                return f"changes the bases or metaclass of {q}"
    return None


def _slots_dump(c: ast.ClassDef) -> str:
    return " ".join(
        ast.dump(s.value)
        for s in c.body
        if isinstance(s, ast.Assign) and any(isinstance(t, ast.Name) and t.id == "__slots__" for t in s.targets)
    )


def evaluated_parts(node: ast.expr) -> list[ast.expr]:
    """The parts of an expression that evaluating it always evaluates: not lambda bodies,
    the branches of `a if c else b`, the operands after the first of `and`/`or` or of
    a chained comparison, or comprehension bodies."""
    out: list[ast.expr] = []
    todo = [node]
    while todo:
        n = todo.pop()
        out.append(n)
        if isinstance(n, ast.Lambda):
            todo.extend(n.args.defaults + [d for d in n.args.kw_defaults if d is not None])
        elif isinstance(n, ast.IfExp):
            todo.append(n.test)
        elif isinstance(n, ast.BoolOp):
            todo.append(n.values[0])
        elif isinstance(n, ast.Compare):
            todo += [n.left, n.comparators[0]]
        elif isinstance(n, (ast.ListComp, ast.SetComp, ast.GeneratorExp, ast.DictComp)):
            todo.append(n.generators[0].iter)
        else:
            for c in ast.iter_child_nodes(n):
                if isinstance(c, ast.keyword):
                    todo.append(c.value)
                elif isinstance(c, ast.expr):
                    todo.append(c)
    return out


def safe_value(new: ast.expr, old: ast.expr) -> bool:
    """True when a class body can evaluate `new` without raising or side effects, given
    that it evaluated `old` at the same place: `new` is built only from literals, tuples,
    lists, sets, dicts, lambdas (their bodies do not run), `not`, `-`/`+` on numbers,
    `and`/`or`/`if`-`else`, and parts that `old` always evaluated (the same names,
    lookups, calls), unpacking only what `old` unpacked and hashing only what it hashed."""
    parts = evaluated_parts(old)
    seen = {ast.dump(n) for n in parts}
    keys, unpacked, starred = set(), set(), set()
    for n in parts:
        if isinstance(n, ast.Dict):
            for k, v in zip(n.keys, n.values):
                (unpacked if k is None else keys).add(ast.dump(v if k is None else k))
        elif isinstance(n, ast.Set):
            keys |= {ast.dump(e) for e in n.elts if not isinstance(e, ast.Starred)}
        if isinstance(n, (ast.List, ast.Tuple, ast.Set)):
            starred |= {ast.dump(e.value) for e in n.elts if isinstance(e, ast.Starred)}

    def hashable(k: ast.expr) -> bool:
        if isinstance(k, ast.Tuple):
            return all(not isinstance(e, ast.Starred) and hashable(e) for e in k.elts)
        return isinstance(k, ast.Constant) or ast.dump(k) in keys

    def ok(n: ast.expr) -> bool:
        if isinstance(n, ast.Constant) or ast.dump(n) in seen:
            return True
        if isinstance(n, (ast.Tuple, ast.List, ast.Set)):
            for e in n.elts:
                if isinstance(e, ast.Starred):
                    if isinstance(n, ast.Set) or ast.dump(e.value) not in starred:
                        return False
                elif not ok(e) or (isinstance(n, ast.Set) and not hashable(e)):
                    return False
            return True
        if isinstance(n, ast.Dict):
            for k, v in zip(n.keys, n.values):
                if k is None:
                    if ast.dump(v) not in unpacked:
                        return False
                elif not (ok(k) and hashable(k) and ok(v)):
                    return False
            return True
        if isinstance(n, ast.UnaryOp):
            if isinstance(n.op, ast.Not):
                return ok(n.operand)
            kinds = (int,) if isinstance(n.op, ast.Invert) else (int, float, complex)
            return isinstance(n.operand, ast.Constant) and type(n.operand.value) in kinds
        if isinstance(n, ast.Lambda):
            return all(ok(d) for d in n.args.defaults + [d for d in n.args.kw_defaults if d is not None])
        if isinstance(n, ast.IfExp):
            return ok(n.test) and ok(n.body) and ok(n.orelse)
        if isinstance(n, ast.BoolOp):
            return all(ok(v) for v in n.values)
        return False

    return ok(new)


def _sole_binding(tree: ast.Module, name: str):
    """The one statement that binds `name` in a module, when it is a module-level def (the
    FunctionDef) or `from m import x [as name]` ((statement, alias)) and nothing else in
    the module, in any scope, binds, deletes or declares `name` (a class body binding it
    would shadow the global there), and there is no star import. Otherwise None."""
    found = []
    for n in ast.walk(tree):
        if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
            if n.name == name:
                found.append(n)
        elif isinstance(n, ast.Name):
            if n.id == name and not isinstance(n.ctx, ast.Load):
                return None
        elif isinstance(n, (ast.Import, ast.ImportFrom)):
            for a in n.names:
                if a.name == "*":
                    return None
                if (a.asname or a.name.split(".")[0]) == name:
                    found.append((n, a))
        elif isinstance(n, (ast.Global, ast.Nonlocal)):
            if name in n.names:
                return None
        elif isinstance(n, (ast.ExceptHandler, ast.MatchAs, ast.MatchStar)):
            if n.name == name:
                return None
        elif isinstance(n, ast.MatchMapping):
            if n.rest == name:
                return None
    if len(found) != 1:
        return None
    b = found[0]
    if isinstance(b, tuple):
        return b if isinstance(b[0], ast.ImportFrom) and any(b[0] is x for x in tree.body) else None
    return b if isinstance(b, ast.FunctionDef) and any(b is x for x in tree.body) else None


def _pure_factory(fn: ast.FunctionDef, lazy_annotations: bool) -> bool:
    """True when calling `fn` (with arguments that bind) only makes and returns a function:
    the body is an optional docstring, one undecorated nested def and `return` of it, or
    only `return lambda ...`. The nested function's defaults (and annotations, unless the
    module defers them) are evaluated at each call; they must not name fn's parameters,
    so they evaluate as in the old call."""
    if fn.decorator_list or getattr(fn, "type_params", None):
        return False
    a = fn.args
    params = {x.arg for x in a.posonlyargs + a.args + a.kwonlyargs} | {x.arg for x in (a.vararg, a.kwarg) if x is not None}
    body = fn.body
    if body and isinstance(body[0], ast.Expr) and isinstance(body[0].value, ast.Constant) and isinstance(body[0].value.value, str):
        body = body[1:]

    def evaluated(args: ast.arguments, returns: ast.expr | None) -> list[ast.expr]:
        parts = args.defaults + [d for d in args.kw_defaults if d is not None]
        if not lazy_annotations:
            every = args.posonlyargs + args.args + args.kwonlyargs + [x for x in (args.vararg, args.kwarg) if x is not None]
            parts += [x.annotation for x in every if x.annotation is not None]
            parts += [returns] if returns is not None else []
        return parts

    def free(parts: list[ast.expr]) -> bool:
        return not any(isinstance(n, ast.Name) and n.id in params for p in parts for n in ast.walk(p))

    if len(body) == 2 and isinstance(body[0], ast.FunctionDef) and isinstance(body[1], ast.Return):
        inner, ret = body
        return (
            not inner.decorator_list
            and not getattr(inner, "type_params", None)
            and isinstance(ret.value, ast.Name)
            and ret.value.id == inner.name
            and free(evaluated(inner.args, inner.returns))
        )
    if len(body) == 1 and isinstance(body[0], ast.Return) and isinstance(body[0].value, ast.Lambda):
        return free(evaluated(body[0].value.args, None))
    return False


def is_docstring(s: Stmt) -> bool:
    node = s.node
    if not (isinstance(node, ast.Expr) and isinstance(node.value, ast.Constant) and isinstance(node.value.value, str)):
        return False
    body = s.parent.node.body if s.parent is not None else None
    return body is None or (body and body[0] is node)


# --------------------------------------------------------------------- selection


class Selector:
    def __init__(self, m: Map) -> None:
        self.m = m
        self.src_cache: dict[str, str | None] = {}
        self.stmt_cache: dict[str, list[Stmt]] = {}
        # Per patch: can its candidate tests be tried with prerun.py? Only when every
        # real change is inside sqlglot function bodies (see prerun.py).
        self.prerun_ok = False
        self.new_sources: dict[str, str] = {}
        self.twins = None  # equiv.Twins, loaded on the first hunk that needs it
        self.lambdas = None  # equiv.Lambdas, likewise
        self.required = None  # equiv.Required, likewise
        self.loadval_index: dict | None = None  # maps/loadval.json, likewise
        self.loadval_old: dict[str, dict | None] = {}  # pinned file -> its watched values
        self.new_trees: dict[str, ast.Module | None] = {}
        self.attrs_index: dict | None = None
        self.mod_defs: dict[str, dict] = {}  # pinned sqlglot module -> its top-level defs (C1)
        self.ms: dict[int, int] = {}  # map test index -> milliseconds (main sets it)
        self.entries_index: dict | None = None
        # Per patch: class users given up by attribute narrowing, and the number of
        # import-time changes (narrowed or not). Narrowing stands only when every
        # import-time change of the patch was narrowed (see select).
        self.attr_users: list[set[int]] = []
        self.import_changes = 0
        self.breaks: dict[str, str | None] = {}  # per patch: import_breaks
        self.may_break: set[str] = set()  # per patch: files whose hunks pass names_or_order_change
        self.old_names: dict[str, tuple[set[str], set[str], bool]] = {}  # pinned modules: import_time_names
        self.py_texts: dict[str, str] | None = None  # pinned sqlglot and test modules, read on first need

    def source(self, path: str) -> str | None:
        if path not in self.src_cache:
            p = SRC / path
            self.src_cache[path] = p.read_text(encoding="utf-8") if p.is_file() else None
        return self.src_cache[path]

    def import_breaks(self, path: str) -> str | None:
        """Why the patched sqlglot module `path` would raise while it loads (where the
        pinned one does not), or None. Rules that narrow an import-time change to the
        tests using a class or a name assume the module still loads; a module that does
        not fails every test that imports it, also through other modules and at test
        collection (tests/test_time.py imports generators/hive.py), and the map has no
        per-test record of imports. Catches a def, class or constant renamed or deleted
        while code that runs at load still names it (TRANSFORMS = {exp.X: _x_sql}),
        mistyped names in class bodies, decorators and defaults, and names moved below
        their first use at load."""
        if path in self.breaks:
            return self.breaks[path]
        why = None
        old = self.source(path)
        parsed = None if old is None else _parse(old, keep=True)
        new_tree = self.new_tree(path)
        if parsed is not None and new_tree is not None:
            if path not in self.old_names:
                self.old_names[path] = import_time_names(parsed[0])
            u_old, b_old, star_old = self.old_names[path]
            u_new, b_new, star_new = import_time_names(new_tree)
            if not (star_old or star_new) and u_new - u_old:
                why = f"loads {sorted(u_new - u_old)[:4]} before anything binds them"
            gone = b_old - b_new
            if why is None and gone:
                where = self.import_users(path, gone)
                if where:
                    why = f"no longer binds {sorted(gone)[:4]}, which {where} imports or reads at load"
            if why is None and LOADATTR:
                bad = self.unknown_load_attrs(parsed[0], new_tree)
                if bad:
                    why = f"reads {bad[:4]} at load, which nothing defines"
        self.breaks[path] = why
        return why

    def unknown_load_attrs(self, old_tree: ast.Module, new_tree: ast.Module) -> list[str]:
        """Attributes the patched module's load-time code reads and the pinned one does not,
        that no attribute of the standard library module they are read from, no word of a
        pinned sqlglot or tests module, and no name an added line of the patch binds can
        supply: a typo such as TRANSFORMS = {exp.ArraySortt: ...} raises AttributeError
        while generators/hive.py loads, which fails every test that loads the hive, spark,
        databricks or athena dialect (probe p43 selected 304)."""
        new = load_attr_reads(new_tree) - load_attr_reads(old_tree)
        if not new:
            return []
        aliases = stdlib_aliases(new_tree)
        out = []
        for base, attr in sorted(new, key=lambda x: (x[0] or "", x[1])):
            if base in aliases:
                try:
                    known = hasattr(__import__(aliases[base], fromlist=["_"]), attr)
                except Exception:
                    known = True
                if not known:
                    out.append(f"{base}.{attr}")
                continue
            word = re.compile(rf"\b{re.escape(attr)}\b")
            if any(word.search(t) for t in self.pinned_py_texts().values()):
                continue
            if re.search(rf"^\+.*(?<![.\w]){re.escape(attr)}\b", self.patch_text, re.M):
                continue  # an added line names it bare: it may define it (class, def, =)
            out.append(attr if base is None else f"{base}.{attr}")
        return out

    def module_file(self, mod: str) -> str | None:
        if not mod.startswith("sqlglot"):
            return None
        for p in (mod.replace(".", "/") + ".py", mod.replace(".", "/") + "/__init__.py"):
            if self.source(p) is not None:
                return p
        return None

    def module_defs(self, mod: str) -> dict:
        """{name: def} for the top-level defs of sqlglot module `mod` as the patch leaves it,
        {} when unknown (no such file, or one the patch changes and nobody parsed yet)."""
        p = self.module_file(mod)
        if p is None:
            return {}
        if p in self.changed_paths:
            tree = self.new_tree(p) if p in self.new_sources else None
            return {} if tree is None else {
                n.name: n for n in tree.body if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef))
            }
        if mod not in self.mod_defs:
            got = _parse(self.source(p), keep=True)
            self.mod_defs[mod] = {} if got is None else {
                n.name: n for n in got[0].body if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef))
            }
        return self.mod_defs[mod]

    def load_time_spot(self, hunks: list[tuple[int, list[str]]], stmts: list[Stmt]) -> int | None:
        """The first changed line outside every function body (code that runs at load), or None."""
        for old_start, body in hunks:
            removed, after = hunk_changes(old_start, body)
            for lo, hi in [(ln, ln) for ln in removed] + [(a, a + 1) for a in after]:
                s = innermost(stmts, lo, hi)
                if s is not None and s.func is not None and s.node is not s.func:
                    continue
                return lo
        return None

    def load_call_break(self, path: str, old_tree: ast.Module, new_tree: ast.Module) -> str | None:
        """Why a call that the patched module's load-time code newly makes raises TypeError:
        its callee is an undecorated def at the top of a sqlglot module, named bare (defined
        here or from-imported: rename_func(...)) or through a module alias
        (generator.unsupported_args(...)), and its arguments do not fit the def's signature.
        Probes p49-p52: rename_func() in hive's TRANSFORMS fails 35 test files at load; the
        class's users were 304 tests."""
        from collections import Counter

        old = Counter(ast.dump(c) for c in load_calls(old_tree))
        new = []
        for c in load_calls(new_tree):
            d = ast.dump(c)
            if old[d] > 0:
                old[d] -= 1
            else:
                new.append(c)
        if not new:
            return None
        here = module_name(path)
        names: dict[str, tuple[str, str]] = {}
        mods: dict[str, str] = {}
        for n in new_tree.body:
            if isinstance(n, ast.ImportFrom):
                if n.level:
                    pkg = here if path.endswith("__init__.py") else here.rpartition(".")[0]
                    for _ in range(n.level - 1):
                        pkg = pkg.rpartition(".")[0]
                    base = f"{pkg}.{n.module}" if n.module else pkg
                else:
                    base = n.module or ""
                for al in n.names:
                    if al.name == "*":
                        continue
                    if self.module_file(f"{base}.{al.name}"):
                        mods[al.asname or al.name] = f"{base}.{al.name}"
                    else:
                        names[al.asname or al.name] = (base, al.name)
            elif isinstance(n, ast.Import):
                for al in n.names:
                    if al.asname and al.name.startswith("sqlglot."):
                        mods[al.asname] = al.name
        local = {n.name: n for n in new_tree.body if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef))}
        for c in new:
            f, fn, label = c.func, None, None
            if isinstance(f, ast.Name):
                label = f.id
                if f.id in local:
                    fn = local[f.id]
                elif f.id in names:
                    fn = self.module_defs(names[f.id][0]).get(names[f.id][1])
            elif isinstance(f, ast.Attribute) and isinstance(f.value, ast.Name) and f.value.id in mods:
                label = f"{f.value.id}.{f.attr}"
                fn = self.module_defs(mods[f.value.id]).get(f.attr)
            if fn is None or fn.decorator_list:
                continue
            why = call_rejects(c, fn)
            if why:
                return f"calls {label} at load with {why}"
        return None

    def new_tree(self, path: str) -> ast.Module | None:
        if path not in self.new_trees:
            try:
                self.new_trees[path] = ast.parse(self.new_sources[path])
            except Exception:
                self.new_trees[path] = None
        return self.new_trees[path]

    def pinned_py_texts(self) -> dict[str, str]:
        if self.py_texts is None:
            self.py_texts = {}
            for top in ("sqlglot", "tests"):
                for p in sorted((SRC / top).rglob("*.py")):
                    try:
                        self.py_texts[p.relative_to(SRC).as_posix()] = p.read_text(encoding="utf-8")
                    except (OSError, UnicodeDecodeError):
                        continue
        return self.py_texts

    def test_file_and_importers(self, path: str) -> tuple[set[int] | None, list[str]]:
        """The tests of test module `path` and of every test module that imports from it
        (33 dialect test files import Validator from tests/dialects/test_dialect.py), or
        ALL if a module that is not a test file imports from it: what a change to its
        import-time code can reach, a break of its import included."""
        mod = re.escape(path[:-3].replace("/", "."))
        own = re.escape(path.rsplit("/", 1)[-1][:-3])
        pattern = re.compile(rf"^\s*(?:from\s+(?:{mod}|\.{own})\s+import\b|import\s+{mod}\b)", re.M)
        importers = [rel for rel, text in self.pinned_py_texts().items() if rel != path and pattern.search(text)]
        if any(not self.is_test_module(rel) for rel in importers):
            return ALL, importers
        got = self.whole_test_file(path)
        for rel in importers:
            got |= self.whole_test_file(rel)
        return got, importers

    def import_break_tests(self, path: str, why: str, lo: int) -> set[int] | None:
        """What to select when import_breaks says the patched `path` raises while it loads:
        every test for a sqlglot module or helper, a test module's tests and its importers'."""
        if self.is_test_module(path):
            got, importers = self.test_file_and_importers(path)
            if got is not ALL:
                log(f"  {path}:{lo}: the patched test module {why}: its import raises -> its {len(got)} tests"
                    + (f" and its {len(importers)} importers'" if importers else ""))
                return got
        log(f"  {path}:{lo}: the patched module {why}: its import raises -> all")
        return ALL

    def class_creation_spot(self, path: str, hunks: list[tuple[int, list[str]]], stmts: list[Stmt]) -> int | None:
        """The first changed line where a hunk can make creating a class raise, or None: a
        __slots__ statement, or class-level code (header, attribute, method name) of a file
        whose hunks change names (names_or_order_change; a token flip does not, so it
        costs nothing). class_creation_break then compares the classes."""
        for old_start, body in hunks:
            removed, after = hunk_changes(old_start, body)
            for lo, hi in [(ln, ln) for ln in removed] + [(a, a + 1) for a in after]:
                s = innermost(stmts, lo, hi)
                if s is None or (s.func is not None and s.node is not s.func):
                    continue  # module level outside statements, or inside a function body
                if not (isinstance(s.node, ast.ClassDef) or s.cls is not None):
                    continue
                if path in self.may_break or (
                    isinstance(s.node, ast.Assign)
                    and any(isinstance(t, ast.Name) and t.id == "__slots__" for t in s.node.targets)
                ):
                    return lo
        return None

    def load_def_decorators(self, path: str, hunks: list[tuple[int, list[str]]], stmts: list[Stmt]) -> tuple[int, str] | None:
        """(line, method) where a hunk changes the decorator lines of a method whose body
        runs while modules load, or None. Those lines lie before the def, so they land on
        the class (its users), not on the def header (H0): removing @classmethod from
        errors.ParseError.new, which the import-time template parse calls, raises at load
        and fails 45 test files (n61decodel06c: 1166 fail, 157 selected)."""
        for old_start, body in hunks:
            removed, after = hunk_changes(old_start, body)
            if not any(l[:1] == "+" and l[1:].lstrip().startswith("@") for l in body):
                after = []  # an insertion there that adds no decorator: a new method, comments
            for lo, hi, gap in [(ln, ln, 0) for ln in removed] + [(a, a + 1, 1) for a in after]:
                s = innermost(stmts, lo, hi)
                if s is None or not isinstance(s.node, ast.ClassDef):
                    continue
                for d in s.node.body:
                    if not isinstance(d, (ast.FunctionDef, ast.AsyncFunctionDef)):
                        continue
                    first = min([x.lineno for x in d.decorator_list] + [d.lineno])
                    stub = all(
                        isinstance(b, ast.Pass) or (isinstance(b, ast.Expr) and isinstance(b.value, ast.Constant))
                        for b in d.body
                    )  # `...`, a docstring: an overload stub, whose def line alone runs at load
                    if first - gap <= lo < d.lineno and not stub and (
                        self.m.ran_at_import(path, d.body[0].lineno, d.end_lineno or d.lineno)
                    ):
                        return lo, f"{s.node.name}.{d.name}"
        return None

    def import_users(self, path: str, gone: set[str]) -> str | None:
        """Another sqlglot or test module that imports one of `gone` by name (anywhere:
        a function's import raises when it runs, in tests the map may not tie to this
        module), or reads it as an attribute or a star-imported name while it loads."""
        pattern = re.compile(r"\b(?:" + "|".join(re.escape(g) for g in sorted(gone)) + r")\b")
        for rel, text in self.pinned_py_texts().items():
            if rel == path or not pattern.search(text):
                continue
            parsed = _parse(text)
            if parsed is None:
                continue
            tree = parsed[0]
            imported, attrs, loads = import_time_refs(tree)
            star = any(isinstance(n, ast.ImportFrom) and any(a.name == "*" for a in n.names) for n in tree.body)
            if gone & imported or gone & attrs or (star and gone & loads):
                return rel
        return None

    def select(self, patch_text: str) -> set[int] | None:
        self.prerun_ok = True
        self.new_sources = {}
        self.new_trees = {}
        self.attr_users = []
        self.import_changes = 0
        self.breaks = {}
        self.may_break = set()
        self.patch_text = patch_text
        files = parse_patch(patch_text)
        self.changed_paths = {p for f in files for p in (f.old_path, f.new_path) if p}
        if not files:
            log("  no files in patch -> all")
            self.prerun_ok = False
            return ALL
        chosen: set[int] = set()
        for fp in files:
            got = self.select_file(fp)
            if got is ALL:
                self.prerun_ok = False
                return ALL
            chosen |= got
        if self.attr_users and self.import_changes > len(self.attr_users):
            # Another import-time change could alter what a narrowed value evaluates
            # (attr_narrow assumes the rest of the module loads as before): undo.
            for users in self.attr_users:
                chosen |= users
            log(f"  attribute narrowing undone: {self.import_changes - len(self.attr_users)} other import-time change(s)")
        return chosen

    def select_file(self, fp: FilePatch) -> set[int] | None:
        path = fp.path
        if not (path.startswith("sqlglot/") and path.endswith(".py")):
            self.prerun_ok = False  # fixtures, tests, data: their own rules
        if not path or (fp.old_path is not None and (fp.hunks or fp.binary) and SRC.is_dir()
                        and not (SRC / fp.old_path).exists()):
            # every patch is against the pinned tree, so we misread its paths
            log(f"  {path!r}: changed file not in the pinned source -> all")
            return ALL
        if fp.binary:
            return self.data_file(path, fp)
        if path in PYTEST_CONFIG or path.endswith("/conftest.py"):
            log(f"  {path}: pytest config -> all")
            return ALL
        if path.endswith(".py") and (path.startswith("sqlglot/") or path.startswith("tests/")):
            return self.python_file(fp)
        return self.data_file(path, fp)

    # ---- data files (fixtures, docs, config)
    def data_file(self, path: str, fp: FilePatch) -> set[int]:
        self.import_changes += 1  # data read while modules load could feed a class attribute
        out: set[int] = set()
        if path.startswith("sqlglotc/"):
            # test_sqlglotc builds the sqlglotc package; setuptools reads its files in
            # ways our read map may not see (pyproject.toml, MANIFEST.in).
            out |= self.whole_test_file("tests/test_sqlglotc.py")
        for p in {fp.old_path, fp.new_path} - {None}:
            got = self.m.set_of(self.m.reads, p)
            if got:
                out |= got
            # a new or deleted file matters to tests that list its directory
            if fp.old_path is None or fp.new_path is None:
                d = p.rsplit("/", 1)[0] + "/" if "/" in p else "./"
                got = self.m.set_of(self.m.reads, d)
                if got:
                    out |= got
        if path.endswith(".py"):
            # Python outside sqlglot/ and tests/ (setup.py, benchmarks, docs tooling):
            # only matters if a test ran it.
            for p in {fp.old_path, fp.new_path} - {None}:
                if p in self.m.lines:
                    log(f"  {path}: python outside the package that tests ran -> all")
                    return ALL
        log(f"  {path}: data file read by {len(out)} tests")
        return out

    # ---- python
    def python_file(self, fp: FilePatch) -> set[int] | None:
        path = fp.path
        if fp.old_path is None or fp.new_path is None or fp.old_path != fp.new_path:
            log(f"  {path}: python file added/removed/renamed -> all")
            return ALL
        old = self.source(path)
        if old is None:
            log(f"  {path}: not in the pinned source -> all")
            return ALL
        old_lines = old.split("\n")
        try:
            new_lines = apply_hunks(old_lines, fp.hunks)
        except PatchError as e:
            log(f"  {path}: patch does not apply ({e}) -> all")
            return ALL
        new = "\n".join(new_lines)
        why = encoding_change(old, new)
        if why:
            log(f"  {path}: {why} -> {'its tests' if self.is_test_module(path) else 'all'}")
            return self.whole_test_file(path) if self.is_test_module(path) else ALL
        if path.startswith(("sqlglot/", "tests/")) and names_or_order_change(fp.hunks):
            self.may_break.add(path)
        if _code_list(new) is None:  # does not compile
            log(f"  {path}: syntax error after patch -> {'its tests' if self.is_test_module(path) else 'all'}")
            return self.whole_test_file(path) if self.is_test_module(path) else ALL
        if same_tree(old, new):
            log(f"  {path}: same compiled code (comments/formatting) -> none")
            return set()
        if UNRUN and path.startswith("sqlglot/") and self.m.never_used(path):
            # Coverage saw no line of it run, in any test or while modules loaded, and the
            # audit hook saw no test open it: no test imports it (test_docs skips it by
            # name), runs it (no test starts `python -m sqlglot`) or reads its text. Tests
            # that list its directory see only names, which a patch to it keeps.
            log(f"  {path}: no test imports, runs or opens this module -> none")
            return set()
        self.new_sources[path] = new

        stmts = self.statements(path, old)
        out: set[int] = set()
        lo = self.class_creation_spot(path, fp.hunks, stmts)
        if lo is not None and self.new_tree(path) is not None:
            why = class_creation_break(_parse(old, keep=True)[0], self.new_tree(path))
            if why:
                got = self.import_break_tests(path, why, lo)
                if got is ALL:
                    return ALL
                out |= got
        hit = self.load_def_decorators(path, fp.hunks, stmts)
        if hit is not None:
            got = self.import_break_tests(path, f"changes the decorators of {hit[1]}, whose body runs at load", hit[0])
            if got is ALL:
                return ALL
            out |= got
        lo = self.load_time_spot(fp.hunks, stmts) if LOADCALL and path.startswith("sqlglot/") else None
        if lo is not None and self.new_tree(path) is not None:
            why = self.load_call_break(path, _parse(old, keep=True)[0], self.new_tree(path))
            if why:
                got = self.import_break_tests(path, why, lo)
                if got is ALL:
                    return ALL
                out |= got
        for old_start, body in fp.hunks:
            if time.monotonic() - STARTED > RUN_BUDGET_S:  # a patch with thousands of hunks
                log(f"  {path}: past the {RUN_BUDGET_S:.0f} s run budget -> all")
                return ALL
            # skip hunks that on their own leave the syntax tree unchanged
            try:
                alone = "\n".join(apply_hunks(old_lines, [(old_start, body)]))
            except PatchError:
                return ALL
            unchanged = same_tree(old, alone)
            if alone != new:
                _COMPILED.pop(alone, None)  # needed only here; one per hunk of a big file is MBs
            if unchanged:
                continue
            if adds_new_name(body, old) and self.only_adds_new_functions(old, alone):
                why = self.import_breaks(path) if path in self.may_break else None
                if why:
                    got = self.import_break_tests(path, why, old_start)
                    if got is ALL:
                        return ALL
                    out |= got
                    continue
                log(f"  {path}: hunk only adds new, unused module-level functions -> none")
                continue
            got = self.twin_hunk(path, old, alone, body, stmts)
            if got is not None:
                log(f"  {path}:{old_start}: hunk only swaps twin comparisons, infected in {len(got)} tests -> {len(got)}")
                out |= got
                continue
            got = self.lambda_hunk(path, old, alone, stmts)
            if got is not None:
                log(f"  {path}:{old_start}: hunk only changes lambda bodies, called in {len(got)} tests -> {len(got)}")
                out |= got
                continue
            got = self.flag_hunk(path, old, alone, body, old_start, stmts)
            if got == "all":
                log(f"  {path}:{old_start}: hunk flips an arg_types flag validated while modules load"
                    " (the import can raise) -> all")
                return ALL
            if got is not None:
                log(f"  {path}:{old_start}: hunk only changes arg_types flags, a flipped key missing in {len(got)} tests -> {len(got)}")
                out |= got
                continue
            why = self.loadval_hunk(path, old, alone)
            if why is not None:
                log(f"  {path}:{old_start}: hunk changes {why}, validated while modules load (the import can raise) -> all")
                return ALL
            removed, after = hunk_changes(old_start, body)
            spots = [(ln, ln) for ln in removed] + [(a, a + 1) for a in after]
            for lo, hi in spots:
                got = self.place(path, stmts, lo, hi)
                if got is ALL:
                    return ALL
                out |= got
        if path.startswith("sqlglot/typing/"):
            # tests/test_typing.py compares the annotators' code objects (co_code, co_consts)
            # without calling them, so no recorded run of the changed code shows it
            out |= self.whole_test_file("tests/test_typing.py")
        return out

    def twin_hunk(self, path: str, old: str, alone: str, body: list[str], stmts: list[Stmt]) -> set[int] | None:
        """Tests a hunk that only swaps comparisons for their twins can affect (equiv.py),
        or None to use the normal rules."""
        if not EQUIV or not TWINS_PATH.is_file():
            return None
        import equiv

        if not equiv.looks_like_twin_swap(body):
            return None
        if self.twins is None:
            self.twins = equiv.Twins(TWINS_PATH, self.m.tests, self.m.tests_by_file)
        return self.twins.hunk(path, old, alone, body, stmts)

    def lambda_hunk(self, path: str, old: str, alone: str, stmts: list[Stmt]) -> set[int] | None:
        """Tests a hunk that only changes lambda bodies can affect: those that called one
        of the lambdas (equiv.py). None to use the normal rules."""
        if not LAMBDA or not path.startswith("sqlglot/") or not LAMBDA_PATH.is_file():
            return None
        import equiv

        spans = equiv.lambda_changes(old, alone, stmts)
        if spans is None:
            return None
        if self.lambdas is None:
            self.lambdas = equiv.Lambdas(LAMBDA_PATH, self.m.tests, self.m.tests_by_file)
        return self.lambdas.spans_tests(path, spans)

    def flag_hunk(self, path: str, old: str, alone: str, body: list[str], old_start: int, stmts: list[Stmt]) -> set[int] | str | None:
        """Tests a hunk that only changes flag values of a class's arg_types literal can
        affect: those where a flipped key was missing when error_messages ran (equiv.py, S7);
        "all" for a key validated while modules load. None to use the normal rules."""
        if not S7 or not path.startswith("sqlglot/") or not REQUIRED_PATH.is_file():
            return None
        removed, _ = hunk_changes(old_start, body)
        if not removed:
            return None
        s = innermost(stmts, min(removed), max(removed))
        if s is None or s.cls is None or not isinstance(s.node, ast.Assign) or "arg_types" not in defined_names(s.node):
            return None
        import equiv

        got = equiv.flag_flips(old, alone, stmts)
        if got is None:
            return None
        if self.required is None:
            self.required = equiv.Required(REQUIRED_PATH, self.m.tests, self.m.tests_by_file)
        tests = self.required.flips_tests(path, *got)
        if tests is not None:
            self.prerun_ok = False  # import-time change, as in place()
            self.import_changes += 1
        return tests

    def loadval_hunk(self, path: str, old: str, alone: str) -> str | None:
        """What a hunk changes that the import-time parse reads on a class it validates, or
        None (BR_LOADVAL, maps/loadval.json): a data attribute read so (arg_types, Min's and
        List's is_var_len_args) of a class generators/duckdb.py's templates build at import,
        or of a class in its MRO up to the attribute's owner, a literal such a class takes keys
        from, or a module dict spread into one (QUERY_MODIFIERS).

        Why all: the parser validates every expression it builds (error_messages), so a
        deleted or renamed key a template sets (UNITTEST "Unexpected keyword", too many
        arguments for Func.from_arg_list), a new required key, or a key moved in a Func
        (from_arg_list maps arguments by position) makes `import sqlglot.dialects.duckdb`
        raise, and every test file importing it fails at collection, also tests that never
        use the class. Flag flips get here only when S7's map cannot vouch for them. Left to
        the other rules: new optional keys (constant, false) where no position moves, that is,
        anywhere when no Func takes the literal, else at its end and with no var-len key."""
        if not LOADVAL or not path.startswith("sqlglot/"):
            return None
        lv = self.loadval()
        if lv is None:
            if not path.startswith("sqlglot/expressions/"):
                return None
            quals = consts = None  # no index: every class and module dict of the file counts
        else:
            quals, consts = lv["literals"].get(path) or {}, lv["constants"].get(path) or {}
            if not quals and not consts:
                return None
        if path not in self.loadval_old:
            self.loadval_old[path] = _watched_values(old, quals, consts)
        a, b = self.loadval_old[path], _watched_values(alone, quals, consts)
        if a is None or b is None:
            return "a file with watched class attributes (no syntax tree)"
        for key in sorted(set(a) | set(b)):
            va, vb = a.get(key), b.get(key)
            if va is not None and vb is not None and [ast.dump(x) for x in va] == [ast.dump(x) for x in vb]:
                continue
            kind, name, attr = key
            if kind == "const":
                info = (consts or {}).get(name) or {"positional": True}
                if va is not None and vb is not None and len(va) == len(vb) == 1 and all(
                    isinstance(x, (ast.Assign, ast.AnnAssign)) for x in va + vb
                ) and _adds_optional_keys(va[0].value, vb[0].value, {"positional": info.get("positional", True), "inner": True}):
                    continue
                return f"{name}, spread into arg_types"
            info = (quals or {}).get(name) or {"positional": True, "varlen": True, "inner": True}
            if attr == "arg_types" and va is not None and vb is not None and len(va) == len(vb) == 1 and _adds_optional_keys(va[0], vb[0], info):
                continue
            return f"{attr} of {name}"
        return None

    def loadval(self) -> dict | None:
        if self.loadval_index is None:
            try:
                raw = json.loads(LOADVAL_PATH.read_text())
                stale = [f for f, size in raw["src"].items() if not (SRC / f).is_file() or (SRC / f).stat().st_size != size]
                if stale:
                    raise ValueError(f"built on another checkout: {stale[:3]}")
                literals: dict[str, dict] = {}
                for key, info in raw["literals"].items():
                    p, q = key.split("::", 1)
                    literals.setdefault(p, {})[q] = info
                constants: dict[str, dict] = {}
                for name, info in raw["constants"].items():
                    for p in info["files"]:
                        constants.setdefault(p, {})[name] = info
                self.loadval_index = {"literals": literals, "constants": constants}
            except Exception as e:
                log(f"  load-validation index unavailable ({e}): every class in sqlglot/expressions counts")
                self.loadval_index = {}
        return self.loadval_index or None

    def only_adds_new_functions(self, old: str, new: str) -> bool:
        """True when `new` is `old` plus module-level functions that cannot matter: no
        decorators, constant defaults only, and a name no sqlglot code defines or reads.
        Defining such a function runs nothing but the def itself.

        `new`'s statements are matched in order against `old`'s (same syntax tree);
        the unmatched ones are the extras. Any extra that is not such a function
        decides the answer (no), so we stop there."""
        pa, pb = _parse(old, keep=True), _parse(new)
        if pa is None or pb is None:
            return False
        (ta, la), (tb, lb) = pa, pb
        a, b = ta.body, tb.body
        known = None
        extra, i = 0, 0
        for s in b:
            if i < len(a) and same_node(s, lb, a[i], la):
                i += 1
                continue
            if known is None:
                known = set(self.m.names) | self.m.import_names
            if not self._harmless_new_function(s, known, old):
                return False
            extra += 1
        return i == len(a) and extra > 0

    @staticmethod
    def _harmless_new_function(s: ast.stmt, known: set[str], old: str) -> bool:
        if not isinstance(s, (ast.FunctionDef, ast.AsyncFunctionDef)) or s.decorator_list:
            return False
        defaults = s.args.defaults + [d for d in s.args.kw_defaults if d is not None]
        if not all(isinstance(d, ast.Constant) for d in defaults):
            return False
        if s.returns is not None or any(arg.annotation is not None for arg in s.args.args):
            return False  # annotations can be evaluated at definition time
        return not (s.name in known or s.name in old)

    def statements(self, path: str, old: str) -> list[Stmt]:
        """The original file's statements, parsed once per run."""
        found = self.stmt_cache.get(path)
        if found is None:
            found = self.stmt_cache[path] = index_statements(_parse(old, keep=True)[0])
        return found

    def is_test_module(self, path: str) -> bool:
        return path.startswith("tests/") and path.rsplit("/", 1)[-1].startswith("test_")

    def whole_test_file(self, path: str) -> set[int]:
        return set(self.m.tests_by_file.get(path, set()))

    def place(self, path: str, stmts: list[Stmt], lo: int, hi: int) -> set[int] | None:
        """Tests affected by a change at old lines lo..hi of a Python file."""
        s = innermost(stmts, lo, hi)
        if s is None:
            log(f"  {path}:{lo}: module level outside any statement -> all")
            return ALL
        m = self.m

        if is_docstring(s):
            self.prerun_ok = False  # doctests read __doc__, which a code swap leaves alone
            docs = self.whole_test_file("tests/test_docs.py")
            log(f"  {path}:{lo}: docstring -> {len(docs)} doc tests")
            return docs

        # Inside a function or method body: the tests that ran this statement.
        if s.func is not None and s.node is not s.func:
            if m.ran_at_import(path, s.start, s.end):
                log(f"  {path}:{lo}: statement runs at import time -> all")
                return ALL
            got = m.line_tests(path, s.start, s.end)
            log(f"  {path}:{lo}: runtime statement {s.start}-{s.end} -> {len(got)} tests")
            return got

        # Everything below runs at import time: not something a code swap can try.
        self.prerun_ok = False
        self.import_changes += 1
        why = self.import_breaks(path) if path in self.may_break else None
        if why:
            return self.import_break_tests(path, why, lo)

        # A def or class header itself (signature, defaults, decorators, bases).
        if isinstance(s.node, (ast.FunctionDef, ast.AsyncFunctionDef)) and lo <= (s.node.body[0].lineno - 1):
            if DEFHEAD_IMPORT and m.ran_at_import(path, s.node.body[0].lineno, s.end):
                log(f"  {path}:{lo}: def header {s.node.name}: body runs at import -> all")
                return ALL
            got = m.line_tests(path, s.start, s.end)
            if DEFAULTS_NARROW and self.defaults_only(path, s, stmts):
                log(f"  {path}:{lo}: def header {s.node.name}: default values only -> {len(got)} tests that ran it")
                return got
            got |= self.names_users(defined_names(s.node)) or set()
            log(f"  {path}:{lo}: def header {s.node.name} -> {len(got)} tests")
            return got

        if self.is_test_module(path):
            # A test module's top-level statement runs when pytest imports the file. A
            # definition or constant only affects that file's tests, but a statement that
            # runs code (`if __name__ ...: unittest.main()`, a call, an import, a loop) can
            # exit or crash the whole pytest session: every test.
            top = s
            while top.parent is not None and not isinstance(top.parent.node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                top = top.parent
            if top.func is None and not isinstance(
                top.node, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef, ast.Assign, ast.AnnAssign)
            ):
                log(f"  {path}:{lo}: test module top-level {type(top.node).__name__} runs at import -> all")
                return ALL
            got, importers = self.test_file_and_importers(path)
            if got is ALL:
                log(f"  {path}:{lo}: test module import-time code, imported by {importers[:3]} -> all")
                return ALL
            log(f"  {path}:{lo}: test module import-time code -> its {len(got)} tests"
                + (f" and its {len(importers)} importers'" if importers else ""))
            return got
        if path.startswith("tests/"):
            log(f"  {path}:{lo}: test helper import-time code -> all")
            return ALL

        # Import-time code in sqlglot: class bodies and module constants.
        # (A change to a class header, or between two statements of its body, lands
        # on the ClassDef itself: it concerns that class and its subclasses.)
        cls_path = s.cls
        if isinstance(s.node, ast.ClassDef):
            cls_path = f"{s.cls}.{s.node.name}" if s.cls else s.node.name
        if cls_path is not None and defined_names(s.node) & REGISTRY_ATTRS:
            log(f"  {path}:{lo}: registry attribute {sorted(defined_names(s.node) & REGISTRY_ATTRS)} -> all")
            return ALL
        if cls_path is not None:
            qual = f"{module_name(path)}.{cls_path}"
            users = m.set_of(m.classes, qual)
            if users is not None and OWNER_USERS:
                via = self.owner_users(qual)
                if via - users:
                    log(f"  {path}:{lo}: {qual} is read through its dialects too: +{len(via - users)} tests")
                users = users | via
            if ENTRY_NARROW:
                got = self.entry_narrow(path, s, qual, users)
                if got is not None:
                    return got
            if users is not None:
                if ATTR_NARROW and isinstance(s.node, ast.Assign):
                    got = self.attr_narrow(path, s, qual, users)
                    if got is not None:
                        return got
                # A plain class attribute only matters to code that reads it by name.
                # Narrow to the class's users that ran such code, unless the name is
                # also read while modules load (a metaclass building tables from it, or
                # another class copying it), where tests depend on it without reading it.
                defined = defined_names(s.node)
                if (
                    isinstance(s.node, (ast.Assign, ast.AnnAssign, ast.AugAssign))
                    and defined
                    and not (defined & m.import_names)
                ):
                    readers = self.names_users(defined)
                    if readers is not None:
                        got = users & readers
                        log(f"  {path}:{lo}: attribute {sorted(defined)} of {qual} -> {len(got)} tests (of {len(users)} users)")
                        return got
                # A name read while modules load can make an import raise (the base Tokenizer's
                # tables tokenize generators/duckdb.py's templates at import), and then every test
                # of each importing file fails at collection, also those that never use the class.
                # Where the users are already 80% of the suite, all costs next to nothing.
                if LOAD_GUARD and defined & m.import_names and (
                    qual in LOAD_PARSE_CLASSES or len(users) * 5 >= len(m.tests) * 4
                ):
                    log(f"  {path}:{lo}: {sorted(defined & m.import_names)} of {qual} read at load, {len(users)} users -> all")
                    return ALL
                log(f"  {path}:{lo}: class-level in {qual} -> {len(users)} tests using it")
                return users
            got = self.names_users(defined_names(s.node))
            if got is not None:
                log(f"  {path}:{lo}: class-level in unused {qual}; names -> {len(got)} tests")
                return got
            log(f"  {path}:{lo}: class-level in unused {qual}, unknown names -> all")
            return ALL

        if isinstance(s.node, (ast.Assign, ast.AnnAssign, ast.AugAssign)):
            defined = defined_names(s.node)
            got = self.names_users(defined)
            if got is not None and MODCONST_GUARD:
                why = self.modconst_unsafe(path, s, defined)
                if why:
                    log(f"  {path}:{lo}: module constant {sorted(defined)}: {why} -> all")
                    return ALL
            if got is not None:
                log(f"  {path}:{lo}: module constant {sorted(defined)} -> {len(got)} tests")
                return got
        log(f"  {path}:{lo}: module-level {type(s.node).__name__} -> all")
        return ALL

    def names_users(self, names: set[str]) -> set[int] | None:
        if not names:
            return None
        out: set[int] = set()
        for n in names:
            got = self.m.set_of(self.m.names, n)
            if got is None:
                return None
            out |= got
        return out

    def owner_users(self, qual: str) -> set[int]:
        """Users of the dialects whose parser/generator/tokenizer class is `qual` or a subclass.

        sqlglot reads those classes' attributes through the dialect, in tests that run no
        method of the class: dialect.parser_class.LOG_DEFAULTS_TO_LN (exp.func),
        self.dialect.tokenizer_class.STRING_ESCAPES (the generator), and the tables
        _Dialect.__new__ derives from them.
        """
        a = self.attrs()
        out: set[int] = set()
        for d in (a or {}).get("owners", {}).get(qual, ()):
            out |= self.m.set_of(self.m.classes, d) or set()
        return out

    def attrs(self) -> dict | None:
        if self.attrs_index is None:
            try:
                import gzip

                with gzip.open(ATTRS_PATH, "rt") as f:
                    raw = json.load(f)
                if raw.get("map") != [MAP_PATH.stat().st_size]:
                    raise ValueError(f"built for another map: {raw.get('map')}")
                raw["import"] = set(raw["import"])
                raw["plain"] = set(raw["plain"])
                raw["doc_names"] = set(raw["doc_names"])
                if "import_names" in raw:
                    raw["import_names"] = set(raw["import_names"])
                    raw["import_owner"] = {q: set(v) for q, v in raw["import_owner"].items()}
                self.attrs_index = raw
            except Exception as e:
                log(f"  attribute index unavailable ({e})")
                self.attrs_index = {}
        return self.attrs_index or None

    def attr_narrow(self, path: str, s: Stmt, qual: str, users: set[int]) -> set[int] | None:
        """Tests for a new value of plain class attributes (`NAME = value` in a class body).

        Why no other test can change outcome: the class body and the rest of the module
        load as before except for this value, which cannot raise or have effects while
        loading (safe_value). Nothing reads the name while modules load (attrs "import":
        metaclasses, __init_subclass__, other class bodies, functions called at import),
        the class's machinery does not read attributes it is not told the name of (attrs
        "plain"; no dunder names; no public *_sql names, which the generator finds with
        dir()), and sqlglot and its tests reach class attributes by computed names nowhere
        else (tools/build_map/attr_index.py). So only code that names the attribute sees
        the new value, and every test that ran such code is in its readers. The result
        is readers & (users | users of the dialects that own the class): code reads this
        class's value with the class or a subclass in use (self/cls bound), or through a
        dialect whose parser/generator/tokenizer class it is (dialect.parser_class.NAME).
        """
        node = s.node
        defined = defined_names(node)
        if not defined or not all(isinstance(t, ast.Name) for t in node.targets):
            return None
        if any((n.startswith("__") and n.endswith("__")) or (n.endswith("_sql") and not n.startswith("_")) for n in defined):
            return None
        a = self.attrs()
        if a is None:
            return None
        blocked = defined & a["import"]
        s5c = False
        if S5C and "import_names" in a:
            # S5c: by name only what import_reads.py cannot see; attribute loads count for the
            # class the lookup found the name in (the default-dialect parse at import reads
            # Dialect's DPIPE_IS_STRING_CONCAT, not a subclass's).
            new = (defined & a["import_names"]) | (defined & a["import_owner"].get(qual, set()))
            s5c = bool(blocked) and not new
            blocked = new
        why = (
            "not a plain class" if qual not in a["plain"]
            else f"read while loading {sorted(blocked)}" if blocked
            else "named in a doctest" if defined & a["doc_names"]
            else "no reader index" if any(n not in a["readers"] for n in defined)
            else None
        )
        if why:
            log(f"  {path}:{s.start}: attribute {sorted(defined)}: {why} -> no narrowing")
            return None
        readers: set[int] = set()
        for n in defined:
            readers.update(a["sets"][a["readers"][n]])
        p = s.parent
        while p is not None:  # directly in classes defined at module level, nested or not
            if not isinstance(p.node, ast.ClassDef):
                return None
            p = p.parent
        old_body = s.parent.node.body
        new_body = self.new_class_body(path, s.cls)
        if new_body is None or len(new_body) != len(old_body):
            return None
        for x, y in zip(old_body, new_body):
            if type(x) is not type(y) or defined_names(x) != defined_names(y):
                return None
        new = new_body[old_body.index(node)]
        if not isinstance(new, ast.Assign) or [ast.dump(t) for t in new.targets] != [ast.dump(t) for t in node.targets]:
            return None
        if not safe_value(new.value, node.value):
            log(f"  {path}:{s.start}: attribute {sorted(defined)} of {qual}: new value may not load as safely -> no narrowing")
            return None
        via = self.owner_users(qual)
        got = (users | via) & readers
        if s5c and sum(self.ms.get(i, 0) for i in got) >= sum(self.ms.get(i, 0) for i in users):
            # Before S5c this edit got the class's users; never pay more than that.
            log(f"  {path}:{s.start}: attribute {sorted(defined)} of {qual}: S5c readers cost no less than users -> users")
            return None
        self.attr_users.append(users)
        log(
            f"  {path}:{s.start}: attribute {sorted(defined)} of {qual} -> {len(got)} tests "
            f"({len(readers)} readers, {len(users)} users, {len((via - users) & readers)} via dialects)"
        )
        return got

    def modconst_unsafe(self, path: str, s: Stmt, defined: set[str]) -> str | None:
        """Why a change to a module-level assignment may change tests that names_users does
        not list (the tests that ran code naming a defined name, used a class whose body
        reads one, or depend on a module-level name built from one), or None.

        Not listed: tests reading what code run while modules load built from the value
        (Map.load_read_names), and, when the new value can raise or act while loading, every
        test of each file importing the module. So the statement must sit directly in the
        module body, the patch must keep it the same assignment, and its new value must load
        as safely as the old (safe_value)."""
        read = defined & self.m.load_read_names()
        if read:
            return f"read while modules load {sorted(read)[:3]}"
        node = s.node
        if s.parent is not None:
            return "not directly in the module body"
        tree = self.new_tree(path)
        if tree is None:
            return "new file does not parse"

        # The same module statements, in the same order (as attr_narrow): a statement the
        # patch adds next to this one (`exp = None`) is not placed anywhere else.
        parsed = _parse(self.source(path) or "", keep=True)
        old_body = parsed[0].body if parsed else []
        if node not in old_body or len(tree.body) != len(old_body):
            return "the patch adds or removes module statements"
        for x, y in zip(old_body, tree.body):
            if type(x) is not type(y) or defined_names(x) != defined_names(y):
                return "the patch adds, removes or moves module statements"
        new, d = tree.body[old_body.index(node)], ast.dump
        targets = node.targets if isinstance(node, ast.Assign) else [node.target]
        if not all(isinstance(t, ast.Name) for t in targets):
            return "not a plain name assignment"  # unpacking can raise; subscripts and attributes mutate
        if isinstance(node, ast.Assign):
            if [d(t) for t in new.targets] != [d(t) for t in node.targets]:
                return "targets changed"
        elif d(new.target) != d(node.target):
            return "target changed"
        elif isinstance(node, ast.AnnAssign) and (d(new.annotation) != d(node.annotation) or new.simple != node.simple):
            return "annotation changed"
        if (new.value is None) != (node.value is None):
            return "value added or removed"
        if isinstance(node, ast.AugAssign) and type(new.op) is not type(node.op):
            return "augmented assignment changed"
        if new.value is not None and d(new.value) != d(node.value):
            if isinstance(node, ast.AugAssign):
                return "augmented assignment changed"  # `x op= value` can raise on a new value
            if not safe_value(new.value, node.value):
                return "new value may not load as safely"
        return None

    def defaults_only(self, path: str, s: Stmt, stmts: list[Stmt]) -> bool:
        """True when the new file has this def with only default values changed.

        Why only the tests that ran the def can change outcome: the def statement evaluates
        the same decorators (none) and annotations, and new defaults that load as safely as
        the old (safe_value), so the module loads as before and the function differs only in
        __defaults__/__kwdefaults__. Every parameter keeps its name, kind and whether it has
        a default, so each call binds or raises TypeError exactly as before, and a call that
        binds and uses a default runs the body: its test ran the def's lines. A body that ran
        while modules load is refused. sqlglot reads parameter names only (inspect at
        optimizer.py and executor/env.py), and no code or test reads __defaults__.
        """
        node = s.node
        if node.decorator_list:
            return False
        p = s.parent
        while p is not None:  # at module level or directly in classes defined there
            if not isinstance(p.node, ast.ClassDef):
                return False
            p = p.parent
        if self.m.ran_at_import(path, node.body[0].lineno, s.end):
            return False
        if s.cls is None:
            if path not in self.new_trees:
                try:
                    self.new_trees[path] = ast.parse(self.new_sources[path])
                except Exception:
                    self.new_trees[path] = None
            tree = self.new_trees[path]
            new_body = None if tree is None else tree.body
        else:
            new_body = self.new_class_body(path, s.cls)
        if new_body is None:
            return False
        named = (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)
        found = [n for n in new_body if isinstance(n, named) and n.name == node.name]
        old = [x for x in stmts if x.parent is s.parent and isinstance(x.node, named) and x.node.name == node.name]
        if len(found) != 1 or len(old) != 1:
            return False
        new = found[0]
        if type(new) is not type(node) or new.decorator_list:
            return False
        if getattr(new, "type_params", None) or getattr(node, "type_params", None):
            return False
        d = ast.dump
        if [d(x) for x in new.body] != [d(x) for x in node.body]:
            return False
        if (new.returns is None) != (node.returns is None) or (new.returns is not None and d(new.returns) != d(node.returns)):
            return False
        a, b = node.args, new.args
        for f in ("posonlyargs", "args", "kwonlyargs"):
            if [d(x) for x in getattr(a, f)] != [d(x) for x in getattr(b, f)]:
                return False
        for f in ("vararg", "kwarg"):
            x, y = getattr(a, f), getattr(b, f)
            if (x is None) != (y is None) or (x is not None and d(x) != d(y)):
                return False
        if len(a.defaults) != len(b.defaults) or [x is None for x in a.kw_defaults] != [x is None for x in b.kw_defaults]:
            return False
        pairs = list(zip(a.defaults, b.defaults)) + [(x, y) for x, y in zip(a.kw_defaults, b.kw_defaults) if x is not None]
        changed = [(x, y) for x, y in pairs if d(x) != d(y)]
        return bool(changed) and all(safe_value(y, x) for x, y in changed)

    def new_class_body(self, path: str, cls_path: str) -> list[ast.stmt] | None:
        if path not in self.new_trees:
            try:
                self.new_trees[path] = ast.parse(self.new_sources[path])
            except Exception:
                self.new_trees[path] = None
        tree = self.new_trees[path]
        if tree is None:
            return None
        body = tree.body
        for name in cls_path.split("."):
            found = [n for n in body if isinstance(n, ast.ClassDef) and n.name == name]
            if len(found) != 1:
                return None
            body = found[0].body
        return body

    def entries(self) -> dict | None:
        if self.entries_index is None:
            try:
                import gzip

                with gzip.open(ENTRIES_PATH, "rt") as f:
                    raw = json.load(f)
                if raw.get("map") != [MAP_PATH.stat().st_size]:
                    raise ValueError(f"built for another map: {raw.get('map')}")
                raw["global"] = set(raw["global"])
                self.entries_index = raw
            except Exception as e:
                log(f"  entry index unavailable ({e})")
                self.entries_index = {}
        return self.entries_index or None

    def entry_narrow(self, path: str, s: Stmt, qual: str, users: set[int] | None) -> set[int] | None:
        """S6. Tests for new values of entries of a dict literal in a class body
        (`NAME = {key: value, **spread, ...}`), its keys and spreads unchanged: the tests that
        read a changed entry's value. None: the other rules decide.

        Why no other test can change outcome. The class body and the rest of the module load
        as before except for the changed values, which cannot raise or have effects while
        loading (safe_value, or the same closure factory called with safe arguments:
        factory_call). The recording (tools/build_map/entries.py) tags each dict this literal
        makes, and the copies and spreads of it, with the entry each value came from, and
        logs per test each entry whose value it read: by key (d[k], get, pop, setdefault),
        wholesale (items, values, ==, repr, deepcopy, pickle), or through C code that copies
        or unpacks the dict ({**d}, dict(d), f(**d), update, format(**d)), which takes the
        per-key path because the tagged dict overrides __iter__. Uses of the keys alone (in,
        len, iteration, a trie of the keys) are the same before and after. No changed entry
        is read by value while modules load or tests are collected (those reads are
        "global"); each test was recorded with sqlglot's caches emptied before it (BR_COLD),
        so a test that would fill a cache from the entry is a reader in any order; reads in
        setup count for the whole test file. So a test that reads no changed entry runs
        exactly as before. If another import-time change of the patch is not narrowed as
        well, select() widens this back to the class's users.
        """
        node = s.node
        if not isinstance(node, (ast.Assign, ast.AnnAssign)) or not isinstance(node.value, ast.Dict):
            return None
        targets = node.targets if isinstance(node, ast.Assign) else [node.target]
        defined = defined_names(node)
        if not all(isinstance(t, ast.Name) for t in targets) or any(n.startswith("__") and n.endswith("__") for n in defined):
            return None
        p = s.parent
        if p is None:
            return None
        while p is not None:  # directly in classes defined at module level, nested or not
            if not isinstance(p.node, ast.ClassDef):
                return None
            p = p.parent
        e = self.entries()
        if e is None:
            return None
        old = node.value
        site = f"{path}:{old.lineno}:{old.col_offset}"
        if e["sites"].get(site) != len(old.keys):
            log(f"  {path}:{s.start}: dict {sorted(defined)} is not in the entry map -> no entry narrowing")
            return None
        old_body = s.parent.node.body
        new_body = self.new_class_body(path, s.cls)
        if new_body is None or len(new_body) != len(old_body):
            return None
        for x, y in zip(old_body, new_body):
            if type(x) is not type(y) or defined_names(x) != defined_names(y):
                return None
        new = new_body[old_body.index(node)]
        if isinstance(node, ast.Assign):
            if [ast.dump(t) for t in new.targets] != [ast.dump(t) for t in node.targets]:
                return None
        elif (ast.dump(new.target), ast.dump(new.annotation), new.simple) != (
            ast.dump(node.target), ast.dump(node.annotation), node.simple
        ):
            return None
        if not isinstance(new.value, ast.Dict) or len(new.value.keys) != len(old.keys):
            return None
        changed = []
        for i, (k, v, nk, nv) in enumerate(zip(old.keys, old.values, new.value.keys, new.value.values)):
            if (k is None) != (nk is None) or (k is not None and ast.dump(k) != ast.dump(nk)):
                return None
            if ast.dump(v) == ast.dump(nv):
                continue
            if k is None or not (safe_value(nv, v) or self.factory_call(path, nv, v)):
                log(f"  {path}:{s.start}: dict {sorted(defined)} entry {i}: new value may not load as safely -> no entry narrowing")
                return None
            changed.append(f"{site}:{i}")
        if not changed:
            return None
        loaded = [c for c in changed if c in e["global"]]
        if loaded:
            log(f"  {path}:{s.start}: dict {sorted(defined)} entries {[c.rsplit(':', 1)[1] for c in loaded]} read while loading -> no entry narrowing")
            return None
        fallback = users if users is not None else self.names_users(defined)
        if fallback is None:
            return None
        got: set[int] = set()
        for c in changed:
            k = e["entries"].get(c)
            for t in e["sets"][k] if k is not None else ():  # None: no test read its value
                if isinstance(t, str):
                    got |= self.whole_test_file(t)  # read in setup
                else:
                    got.add(t)
        self.attr_users.append(fallback)
        log(
            f"  {path}:{s.start}: entries {[c.rsplit(':', 1)[1] for c in changed]} of {qual}.{sorted(defined)[0]} "
            f"-> {len(got)} tests that read them (of {len(fallback)})"
        )
        return got

    def factory_call(self, path: str, new: ast.expr, old: ast.expr) -> bool:
        """`old` and `new` call the same closure factory, a module-level function whose call
        only makes and returns a nested function (_pure_factory), in the same way except
        for safe argument values (safe_value). The new call cannot raise or have effects
        either, and makes a function that differs only in what it captured: only running
        it can show that, and running it needs reading the entry first."""
        if not (isinstance(new, ast.Call) and isinstance(old, ast.Call) and isinstance(old.func, ast.Name)):
            return False
        if ast.dump(new.func) != ast.dump(old.func) or len(new.args) != len(old.args):
            return False
        if [k.arg for k in new.keywords] != [k.arg for k in old.keywords] or None in (k.arg for k in old.keywords):
            return False
        if any(isinstance(a, ast.Starred) for a in old.args + new.args):
            return False
        pairs = list(zip(new.args, old.args)) + [(a.value, b.value) for a, b in zip(new.keywords, old.keywords)]
        if not all(ast.dump(a) == ast.dump(b) or safe_value(a, b) for a, b in pairs):
            return False
        found = self.module_function(path, old.func.id)
        return found is not None and _pure_factory(*found)

    def module_function(self, path: str, name: str, hops: int = 0) -> tuple[ast.FunctionDef, bool] | None:
        """The module-level def that `name` means everywhere in module `path` (followed
        through `from sqlglot.x import name`), and whether that def's module evaluates
        annotations lazily (`from __future__ import annotations`)."""
        src = self.source(path)
        parsed = _parse(src, keep=True) if src is not None and hops < 4 else None
        if parsed is None:
            return None
        tree = parsed[0]
        b = _sole_binding(tree, name)
        if isinstance(b, ast.FunctionDef):
            lazy = any(
                isinstance(n, ast.ImportFrom) and n.module == "__future__" and any(a.name == "annotations" for a in n.names)
                for n in tree.body
            )
            return b, lazy
        if isinstance(b, tuple):
            imp, alias = b
            if imp.level == 0 and imp.module and imp.module.split(".")[0] == "sqlglot":
                base = imp.module.replace(".", "/")
                for cand in (base + ".py", base + "/__init__.py"):
                    if self.source(cand) is not None:
                        return self.module_function(cand, alias.name, hops + 1)
        return None


# ------------------------------------------------------------------------ packing


def pack(tests: list[tuple[int, int]], worker_count: int) -> tuple[list[list[int]], int]:
    """Longest test first, each onto the least-loaded worker. tests = [(number, ms)]."""
    return _pack_sorted(sorted(tests, key=lambda t: t[1], reverse=True), worker_count)


def _pack_sorted(order: list[tuple[int, int]], worker_count: int) -> tuple[list[list[int]], int]:
    workers: list[list[int]] = [[] for _ in range(worker_count)]
    loads = [0] * worker_count
    for number, ms in order:
        lightest = loads.index(min(loads))
        workers[lightest].append(number)
        loads[lightest] += ms
    return workers, max(loads)


def best_split(tests: list[tuple[int, int]]) -> list[list[int]]:
    """The packing with the lowest cost (busiest worker + WORKER_COST_MS per worker);
    on a tie, the fewest workers.

    No packing onto k workers beats max(longest test, ceil(total / k)) for its busiest
    worker (ms are whole numbers), so the counts are tried from the lowest such bound
    up, and a count whose bound cannot beat the best so far is not packed at all."""
    if not tests:
        return []
    order = sorted(tests, key=lambda t: t[1], reverse=True)
    longest, total = order[0][1], sum(ms for _, ms in order)
    bound = {
        k: max(longest, -(-total // k)) + WORKER_COST_MS * k if order[-1][1] >= 0 else float("-inf")
        for k in range(1, min(MAX_WORKERS, len(tests)) + 1)
    }
    best_workers, best_cost, best_k = None, None, None
    for k in sorted(bound, key=lambda k: (bound[k], k)):
        if best_cost is not None and (bound[k], k) > (best_cost, best_k):
            break  # bounds only grow from here
        workers, busiest = _pack_sorted(order, k)
        cost = busiest + WORKER_COST_MS * k
        if best_cost is None or (cost, k) < (best_cost, best_k):
            best_workers, best_cost, best_k = workers, cost, k
    return best_workers


# ------------------------------------------------------------------------ prerun

# Off by default (review, Nov 20): accurate (617 audited verdicts, 0 errors) but it saved
# ~2 s over 73 patches while adding forks, test packages and a time-budget risk.
PRERUN = os.environ.get("BR_PRERUN", "0") == "1"
ELIDE_BIG = os.environ.get("BR_ELIDE", "0") == "1"  # giant-test skip: off until the data supports it
# The only tests the skip may drop: integration giants whose failures came with a cheap
# failure in every labeled mutant (counts in findings/slow-test-subsumption.md). Not every
# slow test: test_annotate_funcs (2 s) is the unit test of function typing and failed alone
# (m21030c).
ELIDE_TESTS = set(os.environ.get("BR_ELIDE_TESTS", "tests/test_executor.py::TestExecutor::test_execute_tpcds").split(","))
AUDIT = os.environ.get("BR_AUDIT", "0") == "1"  # validation: log the runner's verdict on every cheap candidate
PROBE_AUDIT = os.environ.get("BR_PROBE_AUDIT", "0") == "1"  # validation: log infection-probe results
PROBE = os.environ.get("BR_PROBE", "0") == "1"  # infection probe: off until audited on enough patches
PROBE_MIN_REACHED = 10
CHEAP_MS = 1500  # tests at most this long may be run by us; longer ones are scheduled
PRERUN_OVERHEAD_MS = 40  # fork and code swap, per patch
COST_MARGIN = float(os.environ.get("BR_COST_MARGIN", "1.35"))  # our CPU can vary from the calibration run (optimizer tests ran ~1.25x over)
COSTS_PATH = Path(os.environ.get("BR_COSTS", APP / "maps" / "prerun_costs.json"))


class PrerunCosts:
    """Measured CPU of running tests ourselves (tools/calibrate_prerun.py).

    child_ms[nodeid]: a cold forked child running only that test; import_ms[file]:
    importing the test module in the parent, paid once per run. Tests without a
    measurement are never run by us.
    """

    def __init__(self, path: Path) -> None:
        raw = json.loads(path.read_text())
        self.child_ms: dict[str, int] = raw["child_ms"]
        self.import_ms: dict[str, int] = raw["import_ms"]
        # warm_ms: a test's CPU when run after the others of its module in one child
        # (shared lazy setup already paid): the right per-test cost for a batch.
        self.warm_ms: dict[str, int] = raw.get("warm_ms", {})
        self.imported: set[str] = set()
        # Each measurement = the module's one-time work in a fresh child (class setup,
        # lazy sqlglot init) + the test itself. Split them: a module's startup is its
        # cheapest measurement; a test's own cost is what it adds on top of that.
        self.startup_ms: dict[str, int] = {}
        for nodeid, v in self.child_ms.items():
            if v < 10**6:
                f = nodeid.split("::", 1)[0]
                self.startup_ms[f] = min(v, self.startup_ms.get(f, v))

    def test_ms(self, nodeid: str) -> int | None:
        v = self.child_ms.get(nodeid)
        if v is None or v >= 10**6:
            return None
        if nodeid in self.warm_ms:
            return self.warm_ms[nodeid]
        return v - self.startup_ms[nodeid.split("::", 1)[0]]

    def run_ms(self, nodeids: list[str]) -> float:
        files = {n.split("::", 1)[0] for n in nodeids}
        total = sum(self.test_ms(n) for n in nodeids)
        # module startup: its class setup measured in a warm suite when we have it,
        # else the cold child's cheapest test (which includes that setup)
        total += sum(self.warm_ms.get(f"{f}::__setup__", self.startup_ms[f]) for f in files)
        total += sum(self.import_ms.get(f, 500) for f in files - self.imported)
        return COST_MARGIN * total + PRERUN_OVERHEAD_MS


COSTS: PrerunCosts | None = None

# Wall-clock budget for everything we run ourselves (the scorer allows 3 min for the
# practice batch, 4.5 min for the final). Past it, selections stay map-only.
PRERUN_BUDGET_S = float(os.environ.get("BR_PRERUN_BUDGET", "100"))
START = time.monotonic()


def budget_left() -> float:
    return PRERUN_BUDGET_S - (time.monotonic() - START)


def group_tests(nodeids: list[str], file_cost: dict[str, int] | None = None) -> list[str]:
    """Keep each test file and class contiguous: unittest reruns setUpClass whenever the
    class changes (TestExecutor's loads TPC-H and TPC-DS). Files go cheapest first when
    file_cost is given, else in order of first appearance."""
    pos: dict = {}
    for i, x in enumerate(nodeids):
        f, c = x.split("::")[:2]
        pos.setdefault(f, i)
        pos.setdefault((f, c), i)

    def key(item):
        i, x = item
        f, c = x.split("::")[:2]
        return (file_cost.get(f, 0) if file_cost else 0, pos[f], pos[(f, c)], i)

    return [x for _, x in sorted(enumerate(nodeids), key=key)]


def _cpu() -> tuple[float, float]:
    import resource

    me = resource.getrusage(resource.RUSAGE_SELF)
    kids = resource.getrusage(resource.RUSAGE_CHILDREN)
    return me.ru_utime + me.ru_stime, kids.ru_utime + kids.ru_stime


def commit_cost_ms(numbers: list[int], ms: dict[int, int]) -> int:
    workers = best_split([(n, ms[n]) for n in numbers])
    if not workers:
        return 0
    return max(sum(ms[n] for n in w) for w in workers) + WORKER_COST_MS * len(workers)


def try_prerun(runner, selector: "Selector", numbers: list[int], ms, nodeid_of) -> list[int]:
    """Run the cheap candidates against the patched code; keep only those that fail.

    Expensive candidates are always kept (scheduled). Falls back to the full list
    whenever the change is not a pure function-body change or it would not pay.
    """
    import prerun

    swaps = {}
    for path, new in selector.new_sources.items():
        planned = prerun.plan_swaps(str(SRC / path), selector.source(path), new)
        if planned is None:
            log(f"  prerun: {path} is not a pure function-body change")
            return numbers
        swaps[path] = planned
    if not swaps:
        return numbers

    if COSTS is None:
        return numbers
    cheap = [
        n for n in numbers
        if ms[n] <= CHEAP_MS and runner.runnable(nodeid_of[n]) and COSTS.test_ms(nodeid_of[n]) is not None
    ]
    if not cheap:
        return numbers

    if PROBE and len(selector.new_sources) == 1:
        # Infection probe (weak mutation): if the one changed expression runs many
        # times across every cheap candidate test and never yields a different value
        # than the original, the patch cannot change any outcome on those inputs:
        # print nothing. Rare infections exist (1 in 469 in one labeled patch), so the
        # probe covers all cheap candidates, never a sample of them.
        import probe

        (path, new), = selector.new_sources.items()
        plan = probe.plan_probe(str(SRC / path), selector.source(path), new)
        if plan is not None:
            order = sorted(cheap, key=lambda n: COSTS.test_ms(nodeid_of[n]))
            probe_cost = COSTS.run_ms([nodeid_of[n] for n in order])
            schedule_cost = commit_cost_ms(numbers, ms)
            if probe_cost < schedule_cost:
                cpu0 = _cpu()
                out = prerun.probe_run(
                    runner, path, plan, [nodeid_of[n] for n in order], 15 + 3 * probe_cost / 1000,
                    cpu_budget_s=0.8 * schedule_cost / 1000,
                )
                COSTS.imported |= {nodeid_of[n].split("::", 1)[0] for n in order}
                cpu1 = _cpu()
                log(f"  probe: {out} over {len(order)} tests, cpu {sum(cpu1) - sum(cpu0):.2f}s (expected {probe_cost / 1000:.2f}s, schedule {schedule_cost / 1000:.2f}s)")
                if (
                    out and out.get("complete") and not out["failed"]
                    and out["infected"] == 0 and out["reached"] >= PROBE_MIN_REACHED
                ):
                    log(f"  probe: never infected in {out['reached']} evaluations -> none")
                    return []
            else:
                log(f"  probe: not worth it (probe ~{probe_cost / 1000:.1f}s vs schedule {schedule_cost / 1000:.1f}s)")

    if PROBE_AUDIT:
        # Validation only: run an infection probe over the cheap candidates and log
        # how often the changed expression ran and whether it ever changed value.
        import probe

        if len(selector.new_sources) == 1:
            (path, new), = selector.new_sources.items()
            plan = probe.plan_probe(str(SRC / path), selector.source(path), new)
            if plan is not None:
                order = sorted(cheap, key=lambda n: COSTS.test_ms(nodeid_of[n]))
                out = prerun.probe_run(runner, path, plan, [nodeid_of[n] for n in order], 60 + 4 * sum(ms[n] for n in order) / 1000)
                log(f"  PROBE {json.dumps(out)} tests={len(order)}")
        return numbers

    if AUDIT:
        # Validation only: run every cheap candidate and log exactly what the runner
        # says, to compare test by test with labels from the real suite.
        by_nodeid = {nodeid_of[n]: n for n in cheap}
        failed = runner.run(swaps, list(by_nodeid), 30 + 4 * sum(ms[n] for n in cheap) / 1000)
        log(f"  AUDIT ran={sorted(cheap)} failed={sorted(by_nodeid[x] for x in failed if x in by_nodeid)}")
        return numbers

    slow = [n for n in numbers if ms[n] > CHEAP_MS and nodeid_of[n] in ELIDE_TESTS]
    if ELIDE_BIG and slow and budget_left() > 5:
        # Giant-test skip: run every cheap candidate against the patched code, cheapest
        # file first, stopping at the first failure. If none fails, the change survived
        # every cheap test that runs it, and we drop the giants in ELIDE_TESTS too. Justified
        # only by measured data: in labeled mutants these giants never failed unless a
        # cheap candidate also failed (findings/slow-test-subsumption.md on the team board).
        order = sorted(cheap, key=lambda n: COSTS.test_ms(nodeid_of[n]))
        run_cost = COSTS.run_ms([nodeid_of[n] for n in order])
        if_pass = [n for n in numbers if n not in set(order) and n not in set(slow)]
        full_cost = commit_cost_ms(numbers, ms) - commit_cost_ms(if_pass, ms)
        if run_cost < full_cost:
            by_nodeid = {nodeid_of[n]: n for n in order}
            file_ms: dict[str, int] = {}
            for x in by_nodeid:
                f = x.split("::", 1)[0]
                file_ms[f] = file_ms.get(f, 0) + COSTS.test_ms(x)
            deadline = min(15 + 3 * run_cost / 1000, budget_left())
            cpu0 = _cpu()
            failed = runner.run(swaps, group_tests(list(by_nodeid), file_ms), deadline, first_failure=True)
            COSTS.imported |= {n.split("::", 1)[0] for n in by_nodeid}
            cpu1 = _cpu()
            failed_numbers = {by_nodeid[x] for x in failed if x in by_nodeid}
            passed = {by_nodeid[x] for x in runner.last_ran - failed if x in by_nodeid}
            log(
                f"  skip: {len(passed)}/{len(order)} cheap passed, {len(failed_numbers)} failed, "
                f"cpu {sum(cpu1) - sum(cpu0):.2f}s (at most {run_cost / 1000:.2f}s expected, "
                f"saves {full_cost / 1000:.2f}s if all pass)"
            )
            if not failed_numbers and len(passed) == len(order):
                rest = sorted(set(numbers) - passed - set(slow))  # cheap but not runnable here
                log(f"  skip: all {len(order)} cheap candidates pass; dropping {len(slow)} giant(s), keeping {len(rest)}")
                return rest
            # A cheap test failed (or the run broke): the giants stay. Tests that ran
            # and passed are dropped; the rest go through the pay-off rule below.
            numbers = [n for n in numbers if n not in passed]
            cheap = [n for n in cheap if n not in passed and n not in failed_numbers]
            if not cheap:
                return sorted(numbers)
    # Run only the cheap tests whose CPU pays for itself: drop the costliest to run
    # first, while that keeps the saving above the cost.
    cheap.sort(key=lambda n: COSTS.test_ms(nodeid_of[n]))
    best = None
    cuts = range(len(cheap), 0, -1)
    if len(cheap) > 12:  # packing is not free: try a dozen cut points, not all of them
        cuts = sorted({max(1, round(len(cheap) * f)) for f in (1, .9, .8, .7, .6, .5, .4, .3, .2, .1, .05)}, reverse=True)
    for cut in cuts:
        run = cheap[:cut]
        keep = [n for n in numbers if n not in set(run)]
        run_cost = COSTS.run_ms([nodeid_of[n] for n in run])
        saving = commit_cost_ms(numbers, ms) - commit_cost_ms(keep, ms)
        if saving - run_cost > 0 and (best is None or saving - run_cost > best[0]):
            best = (saving - run_cost, run, keep, run_cost, saving)
    if best is None:
        log(f"  prerun: not worth it for {len(cheap)} cheap candidates")
        return numbers
    _, cheap, keep, run_cost, saving = best
    log(f"  prerun: expect cost {run_cost / 1000:.2f}s to save up to {saving / 1000:.2f}s")

    if budget_left() < 5:
        log("  prerun: out of time budget")
        return numbers
    deadline = min(15 + 3 * run_cost / 1000, budget_left())
    by_nodeid = {nodeid_of[n]: n for n in cheap}
    cpu0 = _cpu()
    failed = runner.run(swaps, group_tests(list(by_nodeid)), deadline)
    COSTS.imported |= {n.split("::", 1)[0] for n in by_nodeid}
    cpu1 = _cpu()
    failed_numbers = [by_nodeid[x] for x in failed if x in by_nodeid]
    log(
        f"  prerun: ran {len(cheap)} cheap tests ({sum(ms[n] for n in cheap) / 1000:.2f}s recorded), "
        f"{len(failed_numbers)} failed; keeping {len(keep)} slow ones; "
        f"cpu parent {cpu1[0] - cpu0[0]:.2f}s child {cpu1[1] - cpu0[1]:.2f}s"
    )
    return sorted(set(keep) | set(failed_numbers))


# --------------------------------------------------------------------------- main


def private_stdout():
    """Keep the answer channel to ourselves.

    Anything else that writes to stdout (a library warning, an import-time print)
    would corrupt the answers and reject the run. Duplicate the real stdout for our
    answers, then point file descriptor 1 and sys.stdout at stderr."""
    sys.stdout.flush()
    answers = os.fdopen(os.dup(1), "w", encoding="utf-8", newline="\n")
    os.dup2(2, 1)
    sys.stdout = sys.stderr
    return answers


def main() -> None:
    # Our garbage has no reference cycles worth collecting, so the cycle collector only
    # costs CPU: it rescans the map's millions of objects (~0.15 s per 60 commits). The
    # cheap-test runner makes cyclic garbage (sqlglot trees), so with it the collector stays on.
    if not PRERUN:
        gc.disable()
    answers = private_stdout()
    tests = json.loads((DATA / "tests.json").read_text())["tests"]
    ms = {t["number"]: round(t["seconds"] * 1000) for t in tests}
    all_numbers = [t["number"] for t in tests]

    try:
        m = Map.load(MAP_PATH)
    except Exception as e:  # no map: never miss, run everything
        log(f"map unavailable ({e}); running every test")
        m = None

    number_of = {t["id"]: t["number"] for t in tests}
    unmapped = []
    to_number: dict[int, int] = {}
    if m is not None:
        for i, nodeid in enumerate(m.tests):
            if nodeid in number_of:
                to_number[i] = number_of[nodeid]
        mapped = set(to_number.values())
        unmapped = [n for n in all_numbers if n not in mapped]
        if unmapped:
            log(f"{len(unmapped)} tests are not in the map; they run on every non-empty selection")

    selector = Selector(m) if m is not None else None
    if selector is not None:
        selector.ms = {i: ms[n] for i, n in to_number.items()}
    runner = None
    if PRERUN and hasattr(os, "fork") and SRC.is_dir() and COSTS_PATH.is_file():
        import prerun

        global COSTS
        COSTS = PrerunCosts(COSTS_PATH)
        runner = prerun.Runner(str(SRC), log=log)
    nodeid_of = {t["number"]: t["id"] for t in tests}

    for patch in sorted((DATA / "commits").glob("*.patch")):
        log(f"{patch.stem}:")
        chosen: set[int] | None = ALL
        if selector is not None and time.monotonic() - STARTED > RUN_BUDGET_S:
            log(f"  past the {RUN_BUDGET_S:.0f} s run budget -> all")
        elif selector is not None:
            try:
                # strict: Python will not import a module that is not UTF-8, but with the bad
                # bytes replaced the change can look harmless; the error makes it all
                chosen = selector.select(patch.read_text(encoding="utf-8"))
            except Exception as e:  # any bug of ours must cost time, never a miss
                log(f"  error {e!r} -> all")
                chosen = ALL
        if chosen is ALL:
            numbers = all_numbers
        else:
            numbers = sorted({to_number[i] for i in chosen if i in to_number})
            if numbers and unmapped:
                numbers = sorted(set(numbers) | set(unmapped))
            if runner is not None and numbers and selector.prerun_ok and not unmapped:
                try:
                    numbers = try_prerun(runner, selector, numbers, ms, nodeid_of)
                except Exception as e:  # never a miss: keep the full selection
                    log(f"  prerun error {e!r}; keeping all candidates")
        try:
            workers = best_split([(n, ms[n]) for n in numbers])
            placed = [n for w in workers for n in w]
            if len(workers) > MAX_WORKERS or len(placed) != len(set(placed)) or set(placed) != set(numbers):
                raise ValueError("invalid split")
        except Exception as e:  # a commit without a valid line rejects the whole run
            log(f"  packing error {e!r}; dealing the tests round-robin")
            try:
                deal = sorted(set(numbers) & ms.keys())
            except Exception:
                deal = all_numbers
            workers = [w for w in (deal[i::MAX_WORKERS] for i in range(MAX_WORKERS)) if w]
        log(f"  -> {len(numbers)} tests on {len(workers)} workers")
        answers.write(json.dumps({"commit": patch.stem, "workers": workers}) + "\n")
        answers.flush()


if __name__ == "__main__":
    if sys.argv[1:] == ["--build-cache"]:  # image build time: the map's marshal copy, the pinned files' behaviors
        Map(MAP_PATH).save_cache(MAP_PATH)
        save_behaviors(SRC)
    else:
        main()
