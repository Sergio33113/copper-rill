"""Twin-comparison mutants: which tests can a swap like `is` -> `==` or `<` -> `<=` affect?

maps/twins.json.gz is an offline weak-mutation map (tools/build_map/twins.py): the full suite
was run with every single-operator comparison in sqlglot/ instrumented to also evaluate its
twin (`is`/`==`, `is not`/`!=`, `<`/`<=`, `>`/`>=`) and record in which tests the twin's
result could differ (or either side could raise or have side effects): the site's
"infection" set. By the RIP model a test can only fail on a mutant if the mutated
expression changes value somewhere in its run, so a hunk that only swaps twins needs just
the tests that infect one of its sites: none at all for an equivalent mutant.

A hunk qualifies only if its syntax tree equals the original's with those comparison
operators swapped and nothing else, and every swapped site was reached by the suite. A site
infected during import or collection, or by a test the map does not know, falls back to the
normal rules; one infected in fixture setup or teardown selects its whole test file.
"""

from __future__ import annotations

import ast
import gzip
import json
import re
from pathlib import Path

TWIN = {
    ast.Is: ast.Eq, ast.Eq: ast.Is, ast.IsNot: ast.NotEq, ast.NotEq: ast.IsNot,
    ast.Lt: ast.LtE, ast.LtE: ast.Lt, ast.Gt: ast.GtE, ast.GtE: ast.Gt,
}
TWIN_TOKENS = {
    ("is", "=="), ("==", "is"), ("is not", "!="), ("!=", "is not"),
    ("<", "<="), ("<=", "<"), (">", ">="), (">=", ">"),
}
TOKEN = re.compile(r"\bis\s+not\b|==|!=|<=|>=|->|<<|>>|\w+|\S")


def _tokens(line: str) -> list[str]:
    return [re.sub(r"\s+", " ", t) for t in TOKEN.findall(line)]


def looks_like_twin_swap(body: list[str]) -> bool:
    """Cheap text filter on a hunk: its changed lines pair up and differ only in twin
    comparison operators. The syntax-tree check decides; this only skips the parse."""
    removed = [ln[1:] for ln in body if ln.startswith("-")]
    added = [ln[1:] for ln in body if ln.startswith("+")]
    if not removed or len(removed) != len(added):
        return False
    for a, b in zip(removed, added):
        ta, tb = _tokens(a), _tokens(b)
        if len(ta) != len(tb):
            return False
        diff = [(x, y) for x, y in zip(ta, tb) if x != y]
        if not diff or any(d not in TWIN_TOKENS for d in diff):
            return False
    return True


def _compare(a: ast.AST, b: ast.AST) -> list[tuple[int, int]] | None:
    """Sites (line, col) where tree `b` swaps one of `a`'s comparison operators for its
    twin, if that is the only difference; else None. Changes `a`'s operators."""
    na, nb = list(ast.walk(a)), list(ast.walk(b))
    if len(na) != len(nb):
        return None
    sites = []
    for x, y in zip(na, nb):
        if type(x) is not type(y):
            if isinstance(x, ast.cmpop) and isinstance(y, ast.cmpop):
                continue  # judged at their Compare
            return None
        if isinstance(x, ast.Compare):
            if len(x.ops) != len(y.ops):
                return None
            for i, (p, q) in enumerate(zip(x.ops, y.ops)):
                if type(p) is type(q):
                    continue
                if len(x.ops) != 1 or TWIN.get(type(p)) is not type(q):
                    return None
                sites.append((x.lineno, x.col_offset))
                x.ops[i] = type(q)()
    if not sites or ast.dump(a) != ast.dump(b):
        return None
    return sites


def _lead(line: str) -> str:
    return line[: len(line) - len(line.lstrip())]


def _region(lines: list[str], start: int, end: int, indent: str) -> str:
    """Lines start..end on their own, at their own line and column numbers: blank lines
    before them and, for an indented statement, an `if 1:` block around them."""
    body = "\n".join(lines[start - 1 : end])
    if indent:
        return "\n" * (start - 2) + "if 1:\n" + body
    return "\n" * (start - 1) + body


def twin_swaps(old: str, new: str, stmts=None) -> list[tuple[int, int]] | None:
    """(line, col) in `old` of each comparison swapped for its twin, if that is the only
    difference between the two sources; else None.

    With `stmts` (the old file's statements, with .start/.end/.parent): when both files
    have the same lines except some whose indentation is unchanged, only the innermost
    statement around the changed lines is parsed, from each file. Everything before and
    after it is the same text, so the tokenizer is in the same state when it starts and
    the statement parses to the same tree in place as on its own; its own lines keep their
    indentation, so in place they also form the same blocks."""
    lo, ln = old.split("\n"), new.split("\n")
    if stmts is not None and len(lo) == len(ln):
        changed = [i + 1 for i, (x, y) in enumerate(zip(lo, ln)) if x != y]
        if not changed:
            return None
        first, last = changed[0], changed[-1]
        if all(_lead(lo[i - 1]) == _lead(ln[i - 1]) for i in changed):
            s = None
            for c in stmts:
                if c.start <= first and last <= c.end and (s is None or c.end - c.start <= s.end - s.start):
                    s = c
            while s is not None:
                indent = _lead(lo[s.start - 1])
                if indent and s.start < 2:
                    s = s.parent
                    continue
                try:
                    a = ast.parse(_region(lo, s.start, s.end, indent))
                except SyntaxError:  # e.g. an elif: try the statement around it
                    s = s.parent
                    continue
                try:
                    b = ast.parse(_region(ln, s.start, s.end, indent))
                except SyntaxError:
                    return None
                return _compare(a, b)
    try:
        a, b = ast.parse(old), ast.parse(new)
    except SyntaxError:
        return None
    return _compare(a, b)


class Twins:
    def __init__(self, path: Path, tests: list[str], tests_by_file: dict[str, set[int]]) -> None:
        with gzip.open(path, "rt") as f:
            raw = json.load(f)
        if raw["tests"] != tests:
            raise ValueError("twins map was built for another test list")
        self.seen: set[str] = set(raw["seen"])
        self.inf: dict[str, list] = raw["inf"]  # site -> test numbers, files, or "global"
        self.tests_by_file = tests_by_file

    def site_tests(self, key: str) -> set[int] | None:
        if key not in self.seen:
            return None
        got = self.inf.get(key)
        if got is None:
            return set()
        if got == "global":
            return None
        out: set[int] = set()
        for x in got:
            if isinstance(x, int):
                out.add(x)
            else:
                out |= self.tests_by_file.get(x, set())
        return out

    def hunk(self, path: str, old: str, alone: str, body: list[str], stmts=None) -> set[int] | None:
        """Tests a hunk can affect, or None when the hunk is not (only) twin swaps at
        sites the map can vouch for."""
        if not path.startswith("sqlglot/") or not looks_like_twin_swap(body):
            return None
        sites = twin_swaps(old, alone, stmts)
        if sites is None:
            return None
        out: set[int] = set()
        for ln, col in sites:
            got = self.site_tests(f"{path}:{ln}:{col}")
            if got is None:
                return None
            out |= got
        return out


# ------------------------------------------------------------------- lambda bodies
# maps/lambdas.json.gz (tools/build_map/twins.py with BR_LAMBDAS=1): the tests that called each
# lambda in sqlglot/, keyed by its body's span. Creating a lambda does not evaluate its body, so
# a hunk that changes only lambda bodies can alter only the runs that call one of them: none if
# the suite never calls it. Calls during import or collection (shared state) fall back to the
# normal rules, calls in fixtures select the whole test file, as for twins.


def _region_pair(old: str, new: str, stmts) -> tuple[ast.AST, ast.AST] | None:
    """Trees of the innermost statement around the changed lines, from each file, parsed in
    place as in twin_swaps; None when that does not apply (never parses whole modules)."""
    lo, ln = old.split("\n"), new.split("\n")
    if stmts is None or len(lo) != len(ln):
        return None
    changed = [i + 1 for i, (x, y) in enumerate(zip(lo, ln)) if x != y]
    if not changed or not all(_lead(lo[i - 1]) == _lead(ln[i - 1]) for i in changed):
        return None
    first, last = changed[0], changed[-1]
    s = None
    for c in stmts:
        if c.start <= first and last <= c.end and (s is None or c.end - c.start <= s.end - s.start):
            s = c
    while s is not None:
        indent = _lead(lo[s.start - 1])
        if indent and s.start < 2:
            s = s.parent
            continue
        text = _region(lo, s.start, s.end, indent)
        if "lambda" not in text:
            return None
        try:
            a = ast.parse(text)
        except SyntaxError:
            s = s.parent
            continue
        try:
            b = ast.parse(_region(ln, s.start, s.end, indent))
        except SyntaxError:
            return None
        return a, b
    return None


class _Bodies(ast.NodeTransformer):
    """Replaces the body of every outermost lambda with None, keeping the bodies in order."""

    def __init__(self) -> None:
        self.bodies: list[ast.expr] = []

    def visit_Lambda(self, node: ast.Lambda) -> ast.Lambda:
        node.args = self.visit(node.args)
        self.bodies.append(node.body)
        node.body = ast.Constant(value=None)
        return node


def lambda_changes(old: str, new: str, stmts=None) -> list[tuple[int, int, int, int]] | None:
    """Body spans (line, col, end line, end col) in `old` of the outermost lambdas whose bodies
    differ, if nothing else differs; else None."""
    pair = _region_pair(old, new, stmts)
    if pair is None:
        return None
    sa, sb = _Bodies(), _Bodies()
    a, b = sa.visit(pair[0]), sb.visit(pair[1])
    if len(sa.bodies) != len(sb.bodies) or ast.dump(a) != ast.dump(b):
        return None
    out = [
        (x.lineno, x.col_offset, x.end_lineno, x.end_col_offset)
        for x, y in zip(sa.bodies, sb.bodies)
        if ast.dump(x) != ast.dump(y)
    ]
    return out or None


class Lambdas(Twins):
    def spans_tests(self, path: str, spans: list[tuple[int, int, int, int]]) -> set[int] | None:
        """Tests that called one of these lambdas (spans from lambda_changes), or None when
        the map cannot vouch for one of them."""
        out: set[int] = set()
        for ln, col, eln, ecol in spans:
            got = self.site_tests(f"{path}:{ln}:{col}:{eln}:{ecol}")
            if got is None:
                return None
            out |= got
        return out


# ------------------------------------------------------------------- arg_types flags (S7)
# maps/required.json.gz (tools/build_map/required.py): per arg_types literal entry, the tests in
# which Expression.error_messages ran on a class that gets the entry (the class, subclasses that
# inherit its dict, classes that spread `**C.arg_types`) while the key was missing, and per
# literal the tests in which such a class reported a missing required key. The flag values have
# one reader in sqlglot and its tests, Expr.__init_subclass__ (`required_args`, truth only), and
# `required_args` has one, error_messages. A flip of key k can change a run only at a validation
# where k is missing, or where another required key is missing (the message set and its order);
# a value change that keeps the truth value changes nothing. A key validated while a module
# imports or pytest collects (or in a test the map does not list) selects every test: all such
# keys are optional today (sqlglot.generators.duckdb parses SQL templates at module level), so a
# flip makes the key required where it is missing, that import raises, and every test file that
# imports the module fails at collection, beyond the class's users. "?" (untraced classes,
# unrecorded child processes, tests that never ran under the recorder) goes with every flip.


def flag_flips(old: str, new: str, stmts) -> tuple[str, list[str], list[str]] | None:
    """(class path, keys of the old literal, keys whose flag truth differs) when the only
    change from old to new is constant values inside one class-body `arg_types = {...}`
    literal, parsed in place as in twin_swaps; None otherwise."""
    lo, ln = old.split("\n"), new.split("\n")
    if stmts is None or len(lo) != len(ln):
        return None
    changed = [i + 1 for i, (x, y) in enumerate(zip(lo, ln)) if x != y]
    if not changed or not all(_lead(lo[i - 1]) == _lead(ln[i - 1]) for i in changed):
        return None
    first, last = changed[0], changed[-1]
    s = None
    for c in stmts:
        if c.start <= first and last <= c.end and (s is None or c.end - c.start <= s.end - s.start):
            s = c
    if (
        s is None or s.cls is None or s.func is not None or s.parent is None
        or not isinstance(s.parent.node, ast.ClassDef) or not _is_arg_types(s.node)
    ):
        return None
    indent = _lead(lo[s.start - 1])
    if not indent or s.start < 2:
        return None
    pair = []
    for lines in (lo, ln):
        try:
            tree = ast.parse(_region(lines, s.start, s.end, indent))
        except SyntaxError:
            return None
        body = tree.body[0].body if len(tree.body) == 1 and isinstance(tree.body[0], ast.If) else []
        if len(body) != 1 or not _is_arg_types(body[0]):
            return None
        pair.append(body[0].value)
    a, b = pair
    if len(a.keys) != len(b.keys):
        return None
    keys: list[str] = []
    flips: list[str] = []
    for ka, kb, va, vb in zip(a.keys, b.keys, a.values, b.values):
        if ka is None or kb is None:
            if ka is not kb or ast.dump(va) != ast.dump(vb):
                return None  # spreads must stay as they are
            continue
        if not (isinstance(ka, ast.Constant) and isinstance(ka.value, str)) or ast.dump(ka) != ast.dump(kb):
            return None
        keys.append(ka.value)
        if ast.dump(va) == ast.dump(vb):
            continue
        if not (isinstance(va, ast.Constant) and isinstance(vb, ast.Constant)):
            return None
        if bool(va.value) != bool(vb.value) and ka.value not in flips:
            flips.append(ka.value)
    return s.cls, keys, flips


def _is_arg_types(node: ast.AST) -> bool:
    return (
        isinstance(node, ast.Assign) and len(node.targets) == 1 and isinstance(node.targets[0], ast.Name)
        and node.targets[0].id == "arg_types" and isinstance(node.value, ast.Dict)
    )


class Required:
    def __init__(self, path: Path, tests: list[str], tests_by_file: dict[str, set[int]]) -> None:
        with gzip.open(path, "rt") as f:
            raw = json.load(f)
        if raw["tests"] != tests:
            raise ValueError("required map was built for another test list")
        self.known: dict[str, list[str]] = raw["known"]
        self.inf: dict[str, list] = raw["inf"]
        self.tests_by_file = tests_by_file

    def site_tests(self, key: str) -> set[int] | None:
        got = self.inf.get(key)
        if got is None:
            return set()
        if got == "global":
            return None
        out: set[int] = set()
        for x in got:
            if isinstance(x, int):
                out.add(x)
            else:
                out |= self.tests_by_file.get(x, set())
        return out

    def flips_tests(self, path: str, cls: str, keys: list[str], flips: list[str]) -> set[int] | str | None:
        """Tests a flip of these keys of cls's literal can affect; "all" when one of its sites
        was validated during an import or collection; None when the map cannot vouch for the
        literal (not traced, other keys)."""
        lit = f"{path}::{cls}"
        if self.known.get(lit) != keys:
            return None
        if not flips:
            return set()
        out: set[int] = set()
        for key in [f"{lit}::{k}" for k in flips] + [f"{lit}::*", "?"]:
            got = self.site_tests(key)
            if got is None:
                return "all"
            out |= got
        return out
