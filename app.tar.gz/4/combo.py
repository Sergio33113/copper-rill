"""Entry point: two independent selectors; the second one decides, the first one narrows.

1. selector.py (ours: per-test coverage map, static rules, recorded-value maps) answers every
   commit, in about a second for the whole batch.
2. a/selector.py (the team's other line: it imports the patched code and compares the
   import-time state of every class and module with the pinned commit's, and re-checks the
   slow executor test) is then asked about every commit. It is told the first answer
   (BR_UNIVERSE) and does the combining itself, commit by commit:
   - where the first answer rests on fine-grained rules only (FINE_RULES: rules that know
     who can see the change), a test runs only if both select it (each is built to select
     every test the patch can fail);
   - its own answer stands whole everywhere else, and also when it selects every test or
     its import check sees the patch change state beyond the attributes it edits (a value
     another class copied while modules loaded: only that check knows who reads the copies).
3. The second selector's line is the answer, unless the first selector saw something the
   second does not look at (VETO_RULES: source Python cannot decode, a class that cannot be
   created or loaded, a patch neither can place): then every test runs. Where the second has
   no line, the first answer stands; where neither has one, every test runs.

FINE_RULES below are the first selector's rules that count as fine-grained, recognised in
its log. A commit with any other reason line is not "fine": unknown wording errs towards
the second selector's whole answer.

Anything that goes wrong costs time, never a missed test. Switches: BR_COMBO=0 (first
selector only), BR_COMBO_MIN_S (ask the second only when the first answer costs at least
this many simulated seconds; default: always ask).
"""

from __future__ import annotations

import json
import os
import re
import signal
import subprocess
import sys
import tempfile
import time
from pathlib import Path

STARTED = time.monotonic()
APP = Path(__file__).resolve().parent
DATA = Path(os.environ.get("BR_DATA", "/data"))
SRC = Path(os.environ.get("BR_SRC", APP / "src"))
SECOND = APP / "a" / "selector.py"
COMBO = os.environ.get("BR_COMBO", "1") == "1"
# Default: ask about every commit. An empty first answer costs the second selector nothing
# unless the patch changes what runs at import, and then its check is the one thing that
# sees a patched module that no longer imports.
MIN_COST_MS = int(float(os.environ.get("BR_COMBO_MIN_S", "-1")) * 1000)
# The batch has 180 s of wall time. The first selector normally needs about a second; the
# second one keeps its own deadlines (given below, counted from its own start) and is
# stopped outright at HARD_STOP_S after ours, leaving time to print.
FIRST_TIMEOUT_S = float(os.environ.get("BR_COMBO_FIRST_TIMEOUT", "100"))
HARD_STOP_S = float(os.environ.get("BR_COMBO_HARD_STOP", "170"))
SECOND_EC_DEADLINE_S = 145.0
SECOND_CA_DEADLINE_S = 160.0

MAX_WORKERS = 8
WORKER_COST_MS = 2000

# The first selector's reason lines (after "path:line: ") that name a rule which knows who
# can see the change. Everything else, the "class-level in X -> N tests using it" fallback
# in particular, is not fine.
# Not here on purpose: "hunk only swaps twin comparisons" (maps/twins.json.gz, read per test).
# It takes `==` between two sqlglot expressions for side-effect free; the second selector's
# own comparison map does not (`==` hashes both trees and caches the hashes), and on 86 of
# 160 twin swaps the two recordings disagree. Until labels settle that, the second
# selector's answer for a twin swap stands.
FINE_RULES = [re.compile(x) for x in (
    r"same compiled code \(comments/formatting\) -> none$",
    r"docstring -> \d+ doc tests?$",
    r"runtime statement \d+(-\d+)? -> \d+ tests?$",
    r"data file read by \d+ tests?$",
    r"hunk only changes lambda bodies, called in \d+ tests? -> \d+$",
    r"hunk only changes arg_types flags, a flipped key missing in \d+ tests? -> \d+$",
    r"entries \[[^\]]*\] of \S+ -> \d+ tests? that read them \(of \d+\)$",
    r"attribute \[[^\]]*\] of \S+ -> \d+ tests? \(\d+ readers, \d+ users, \d+ via dialects\)$",
)]
# The first selector's reasons that end the discussion: every test runs, whatever the second
# selector says. Each names something the second selector does not look at: source bytes Python
# cannot decode (a coding cookie, a patch that is not UTF-8), a class its own static checks show
# cannot be created or loaded (__slots__ clashes, load-time names, calls and decorators), and
# patches neither can place. Its other "-> all" lines are cautious guesses about import-time
# code, which the second selector settles by importing the patched code.
VETO_RULES = [re.compile(x) for x in (
    r"the patched module .*: its import raises -> all$",
    r"coding cookie: the import cannot decode the file -> all$",
    r"error .* -> all$",
    r"no files in patch -> all$",
    r"changed file not in the pinned source -> all$",
    r"not in the pinned source -> all$",
    r"pytest config -> all$",
    r"python outside the package that tests ran -> all$",
    r"python file added/removed/renamed -> all$",
    r"patch does not apply .* -> all$",
)]
HEADER = re.compile(r"(\S+):")
REASON = re.compile(r"  (?:\S+?:(?:\d+:)? )?(.*)")


def read_log(log_text: str, commits: set) -> tuple[set, set]:
    """From the first selector's log: the commits whose every reason line is a fine-grained
    rule, and the commits with a reason line that ends the discussion (VETO_RULES)."""
    fine, veto, current, ok, seen = set(), set(), None, False, 0

    def close():
        if current is not None and ok and seen:
            fine.add(current)

    for line in log_text.split("\n"):
        m = HEADER.fullmatch(line)
        if m and m.group(1) in commits:
            close()
            current, ok, seen = m.group(1), True, 0
            continue
        if current is None or not line.startswith("  ") or line.startswith("  -> "):
            continue
        m = REASON.fullmatch(line)
        reason = m.group(1).strip() if m else line.strip()
        seen += 1
        if not any(r.fullmatch(reason) for r in FINE_RULES):
            ok = False
        if any(r.fullmatch(reason) or r.fullmatch(line.strip()) for r in VETO_RULES):
            veto.add(current)
    close()
    return fine, veto


def fine_commits(log_text: str, commits: set) -> set:
    return read_log(log_text, commits)[0]


def log(msg: str) -> None:
    print(msg, file=sys.stderr, flush=True)


def private_stdout():
    """Our answers go to the real stdout; everything else that writes to fd 1 goes to stderr."""
    sys.stdout.flush()
    answers = os.fdopen(os.dup(1), "w", encoding="utf-8", newline="\n")
    os.dup2(2, 1)
    sys.stdout = sys.stderr
    return answers


def _pack_sorted(order, worker_count):
    workers = [[] for _ in range(worker_count)]
    loads = [0] * worker_count
    for number, ms in order:
        lightest = loads.index(min(loads))
        workers[lightest].append(number)
        loads[lightest] += ms
    return workers, max(loads)


def best_split(tests):
    """selector.py's packing: longest first onto the least-loaded worker, the worker count
    with the lowest cost (busiest worker + 2 s per worker), fewest workers on a tie."""
    if not tests:
        return []
    order = sorted(tests, key=lambda t: t[1], reverse=True)
    best_workers, best_cost = None, None
    for k in range(1, min(MAX_WORKERS, len(order)) + 1):
        workers, busiest = _pack_sorted(order, k)
        cost = busiest + WORKER_COST_MS * k
        if best_cost is None or cost < best_cost:
            best_workers, best_cost = workers, cost
    return best_workers


def cost_of(workers, ms) -> int:
    used = [w for w in workers if w]
    if not used:
        return 0
    return max(sum(ms[n] for n in w) for w in used) + WORKER_COST_MS * len(used)


def run_selector(cmd, env, timeout_s, keep_log=False):
    """The selector's stdout (and its log, if asked), also when it had to be stopped (its
    answers are flushed one commit at a time). Its whole process group goes with it."""
    err = None
    try:
        proc = subprocess.Popen(cmd, env=env, stdout=subprocess.PIPE,
                                stderr=subprocess.PIPE if keep_log else None, start_new_session=True)
    except Exception as e:
        log(f"combo: cannot start {cmd[-1]}: {e!r}")
        return b"", b""
    try:
        out, err = proc.communicate(timeout=max(1.0, timeout_s))
    except subprocess.TimeoutExpired:
        log(f"combo: {cmd[-1]} stopped after {timeout_s:.0f} s")
        try:
            os.killpg(proc.pid, signal.SIGKILL)
        except OSError:
            proc.kill()
        out, err = proc.communicate()
    except Exception as e:
        log(f"combo: {cmd[-1]} failed: {e!r}")
        try:
            os.killpg(proc.pid, signal.SIGKILL)
        except OSError:
            pass
        return b"", b""
    if proc.returncode != 0:
        log(f"combo: {cmd[-1]} exited with {proc.returncode}")
    if err:
        sys.stderr.write(err.decode("utf-8", "replace"))
        sys.stderr.flush()
    return out or b"", err or b""


def parse(out: bytes, commits: set, ms: dict) -> dict:
    """commit -> workers for every well-formed answer line; anything else is ignored."""
    got = {}
    for line in out.decode("utf-8", "replace").split("\n"):
        if not line.strip():
            continue
        try:
            row = json.loads(line)
            commit, workers = row["commit"], row["workers"]
            if commit not in commits or commit in got or not isinstance(workers, list):
                continue
            seen = set()
            ok = True
            for w in workers:
                if not isinstance(w, list):
                    ok = False
                    break
                for n in w:
                    if type(n) is not int or n not in ms or n in seen:
                        ok = False
                        break
                    seen.add(n)
                if not ok:
                    break
            if ok and len([w for w in workers if w]) <= MAX_WORKERS:
                got[commit] = workers
        except Exception:
            continue
    return got


def main() -> None:
    answers = private_stdout()
    tests = json.loads((DATA / "tests.json").read_text())["tests"]
    ms = {t["number"]: round(t["seconds"] * 1000) for t in tests}
    all_numbers = [t["number"] for t in tests]
    patches = sorted((DATA / "commits").glob("*.patch"))
    commits = [p.stem for p in patches]
    known = set(commits)

    env = dict(os.environ)
    env["PYTHONPATH"] = os.pathsep.join(x for x in (str(APP), env.get("PYTHONPATH")) if x)
    out, first_log = run_selector([sys.executable, "-P", "-m", "selector"], env, FIRST_TIMEOUT_S, keep_log=True)
    first = parse(out, known, ms)
    try:
        fine, veto = read_log(first_log.decode("utf-8", "replace"), known)
        fine &= set(first)
        # a veto needs the first selector to have answered with every test
        veto = {c for c in veto if c in first and sum(len(w) for w in first[c]) == len(all_numbers)}
    except Exception as e:  # never a miss: no commit counts as fine
        log(f"combo: cannot read the first selector's log: {e!r}")
        fine, veto = set(), set()
    if len(first) != len(commits):
        log(f"combo: the first selector answered {len(first)} of {len(commits)} commits")

    second: dict = {}
    ask = []
    if COMBO and SECOND.is_file():
        for c in commits:
            if c not in first:
                ask.append(c)
            elif cost_of(first[c], ms) >= MIN_COST_MS:
                ask.append(c)
    if ask:
        try:
            tmp = Path(tempfile.mkdtemp(prefix="combo-"))
            (tmp / "commits").mkdir()
            for c in ask:
                os.symlink(DATA / "commits" / f"{c}.patch", tmp / "commits" / f"{c}.patch")
            os.symlink(DATA / "tests.json", tmp / "tests.json")
            universe = {c: sorted({n for w in first[c] for n in w}) for c in ask if c in first}
            (tmp / "universe.json").write_text(json.dumps({"tests": universe, "fine": sorted(fine)}))
            used = time.monotonic() - STARTED
            env = {k: v for k, v in os.environ.items() if k != "PYTHONPATH"}
            env.update(
                BR_DATA=str(tmp), BR_SRC=str(SRC), BR_UNIVERSE=str(tmp / "universe.json"),
                BR_EC_DEADLINE=str(max(5.0, SECOND_EC_DEADLINE_S - used)),
                BR_CA_DEADLINE=str(max(10.0, SECOND_CA_DEADLINE_S - used)),
                PYTHONDONTWRITEBYTECODE="1",
            )
            out, _ = run_selector([sys.executable, str(SECOND)], env, HARD_STOP_S - used)
            second = parse(out, set(ask), ms)
        except Exception as e:  # never a miss: the first answers stand
            log(f"combo: second selector not used: {e!r}")
            second = {}
        log(f"combo: asked the second selector about {len(ask)} of {len(commits)} commits, "
            f"{len(second)} answered, {len(fine)} fine, {len(veto)} vetoed, {time.monotonic() - STARTED:.1f} s so far")

    for c in commits:
        w1, w2 = first.get(c), second.get(c)
        if c in veto:
            workers = w1  # every test: the first selector saw something the second does not look at
        elif w2 is not None:
            workers = w2  # the second selector's line: already combined with the first answer
        elif w1 is not None:
            workers = w1
        else:
            workers = best_split([(n, ms[n]) for n in all_numbers])
        answers.write(json.dumps({"commit": c, "workers": [w for w in workers if w]}) + "\n")
    answers.flush()


if __name__ == "__main__":
    main()
